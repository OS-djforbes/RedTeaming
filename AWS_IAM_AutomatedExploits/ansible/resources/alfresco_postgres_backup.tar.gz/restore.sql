--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.1 (Debian 13.1-1.pgdg100+1)
-- Dumped by pg_dump version 13.1 (Debian 13.1-1.pgdg100+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE alfresco;
--
-- Name: alfresco; Type: DATABASE; Schema: -; Owner: alfresco
--

CREATE DATABASE alfresco WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE alfresco OWNER TO alfresco;

\connect alfresco

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: act_evt_log; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.act_evt_log (
    log_nr_ integer NOT NULL,
    type_ character varying(64),
    proc_def_id_ character varying(64),
    proc_inst_id_ character varying(64),
    execution_id_ character varying(64),
    task_id_ character varying(64),
    time_stamp_ timestamp without time zone NOT NULL,
    user_id_ character varying(255),
    data_ bytea,
    lock_owner_ character varying(255),
    lock_time_ timestamp without time zone,
    is_processed_ smallint DEFAULT 0
);


ALTER TABLE public.act_evt_log OWNER TO alfresco;

--
-- Name: act_evt_log_log_nr__seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.act_evt_log_log_nr__seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.act_evt_log_log_nr__seq OWNER TO alfresco;

--
-- Name: act_evt_log_log_nr__seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alfresco
--

ALTER SEQUENCE public.act_evt_log_log_nr__seq OWNED BY public.act_evt_log.log_nr_;


--
-- Name: act_ge_bytearray; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.act_ge_bytearray (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    name_ character varying(255),
    deployment_id_ character varying(64),
    bytes_ bytea,
    generated_ boolean
);


ALTER TABLE public.act_ge_bytearray OWNER TO alfresco;

--
-- Name: act_ge_property; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.act_ge_property (
    name_ character varying(64) NOT NULL,
    value_ character varying(300),
    rev_ integer
);


ALTER TABLE public.act_ge_property OWNER TO alfresco;

--
-- Name: act_hi_actinst; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.act_hi_actinst (
    id_ character varying(64) NOT NULL,
    proc_def_id_ character varying(64) NOT NULL,
    proc_inst_id_ character varying(64) NOT NULL,
    execution_id_ character varying(64) NOT NULL,
    act_id_ character varying(255) NOT NULL,
    task_id_ character varying(64),
    call_proc_inst_id_ character varying(64),
    act_name_ character varying(255),
    act_type_ character varying(255) NOT NULL,
    assignee_ character varying(255),
    start_time_ timestamp without time zone NOT NULL,
    end_time_ timestamp without time zone,
    duration_ bigint,
    tenant_id_ character varying(255) DEFAULT ''::character varying
);


ALTER TABLE public.act_hi_actinst OWNER TO alfresco;

--
-- Name: act_hi_attachment; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.act_hi_attachment (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    user_id_ character varying(255),
    name_ character varying(255),
    description_ character varying(4000),
    type_ character varying(255),
    task_id_ character varying(64),
    proc_inst_id_ character varying(64),
    url_ character varying(4000),
    content_id_ character varying(64),
    time_ timestamp without time zone
);


ALTER TABLE public.act_hi_attachment OWNER TO alfresco;

--
-- Name: act_hi_comment; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.act_hi_comment (
    id_ character varying(64) NOT NULL,
    type_ character varying(255),
    time_ timestamp without time zone NOT NULL,
    user_id_ character varying(255),
    task_id_ character varying(64),
    proc_inst_id_ character varying(64),
    action_ character varying(255),
    message_ character varying(4000),
    full_msg_ bytea
);


ALTER TABLE public.act_hi_comment OWNER TO alfresco;

--
-- Name: act_hi_detail; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.act_hi_detail (
    id_ character varying(64) NOT NULL,
    type_ character varying(255) NOT NULL,
    proc_inst_id_ character varying(64),
    execution_id_ character varying(64),
    task_id_ character varying(64),
    act_inst_id_ character varying(64),
    name_ character varying(255) NOT NULL,
    var_type_ character varying(64),
    rev_ integer,
    time_ timestamp without time zone NOT NULL,
    bytearray_id_ character varying(64),
    double_ double precision,
    long_ bigint,
    text_ character varying(4000),
    text2_ character varying(4000)
);


ALTER TABLE public.act_hi_detail OWNER TO alfresco;

--
-- Name: act_hi_identitylink; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.act_hi_identitylink (
    id_ character varying(64) NOT NULL,
    group_id_ character varying(255),
    type_ character varying(255),
    user_id_ character varying(255),
    task_id_ character varying(64),
    proc_inst_id_ character varying(64)
);


ALTER TABLE public.act_hi_identitylink OWNER TO alfresco;

--
-- Name: act_hi_procinst; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.act_hi_procinst (
    id_ character varying(64) NOT NULL,
    proc_inst_id_ character varying(64) NOT NULL,
    business_key_ character varying(255),
    proc_def_id_ character varying(64) NOT NULL,
    start_time_ timestamp without time zone NOT NULL,
    end_time_ timestamp without time zone,
    duration_ bigint,
    start_user_id_ character varying(255),
    start_act_id_ character varying(255),
    end_act_id_ character varying(255),
    super_process_instance_id_ character varying(64),
    delete_reason_ character varying(4000),
    tenant_id_ character varying(255) DEFAULT ''::character varying,
    name_ character varying(255)
);


ALTER TABLE public.act_hi_procinst OWNER TO alfresco;

--
-- Name: act_hi_taskinst; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.act_hi_taskinst (
    id_ character varying(64) NOT NULL,
    proc_def_id_ character varying(64),
    task_def_key_ character varying(255),
    proc_inst_id_ character varying(64),
    execution_id_ character varying(64),
    name_ character varying(255),
    parent_task_id_ character varying(64),
    description_ character varying(4000),
    owner_ character varying(255),
    assignee_ character varying(255),
    start_time_ timestamp without time zone NOT NULL,
    claim_time_ timestamp without time zone,
    end_time_ timestamp without time zone,
    duration_ bigint,
    delete_reason_ character varying(4000),
    priority_ integer,
    due_date_ timestamp without time zone,
    form_key_ character varying(255),
    category_ character varying(255),
    tenant_id_ character varying(255) DEFAULT ''::character varying
);


ALTER TABLE public.act_hi_taskinst OWNER TO alfresco;

--
-- Name: act_hi_varinst; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.act_hi_varinst (
    id_ character varying(64) NOT NULL,
    proc_inst_id_ character varying(64),
    execution_id_ character varying(64),
    task_id_ character varying(64),
    name_ character varying(255) NOT NULL,
    var_type_ character varying(100),
    rev_ integer,
    bytearray_id_ character varying(64),
    double_ double precision,
    long_ bigint,
    text_ character varying(4000),
    text2_ character varying(4000),
    create_time_ timestamp without time zone,
    last_updated_time_ timestamp without time zone
);


ALTER TABLE public.act_hi_varinst OWNER TO alfresco;

--
-- Name: act_id_group; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.act_id_group (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    name_ character varying(255),
    type_ character varying(255)
);


ALTER TABLE public.act_id_group OWNER TO alfresco;

--
-- Name: act_id_info; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.act_id_info (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    user_id_ character varying(64),
    type_ character varying(64),
    key_ character varying(255),
    value_ character varying(255),
    password_ bytea,
    parent_id_ character varying(255)
);


ALTER TABLE public.act_id_info OWNER TO alfresco;

--
-- Name: act_id_membership; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.act_id_membership (
    user_id_ character varying(64) NOT NULL,
    group_id_ character varying(64) NOT NULL
);


ALTER TABLE public.act_id_membership OWNER TO alfresco;

--
-- Name: act_id_user; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.act_id_user (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    first_ character varying(255),
    last_ character varying(255),
    email_ character varying(255),
    pwd_ character varying(255),
    picture_id_ character varying(64)
);


ALTER TABLE public.act_id_user OWNER TO alfresco;

--
-- Name: act_procdef_info; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.act_procdef_info (
    id_ character varying(64) NOT NULL,
    proc_def_id_ character varying(64) NOT NULL,
    rev_ integer,
    info_json_id_ character varying(64)
);


ALTER TABLE public.act_procdef_info OWNER TO alfresco;

--
-- Name: act_re_deployment; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.act_re_deployment (
    id_ character varying(64) NOT NULL,
    name_ character varying(255),
    category_ character varying(255),
    tenant_id_ character varying(255) DEFAULT ''::character varying,
    deploy_time_ timestamp without time zone
);


ALTER TABLE public.act_re_deployment OWNER TO alfresco;

--
-- Name: act_re_model; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.act_re_model (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    name_ character varying(255),
    key_ character varying(255),
    category_ character varying(255),
    create_time_ timestamp without time zone,
    last_update_time_ timestamp without time zone,
    version_ integer,
    meta_info_ character varying(4000),
    deployment_id_ character varying(64),
    editor_source_value_id_ character varying(64),
    editor_source_extra_value_id_ character varying(64),
    tenant_id_ character varying(255) DEFAULT ''::character varying
);


ALTER TABLE public.act_re_model OWNER TO alfresco;

--
-- Name: act_re_procdef; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.act_re_procdef (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    category_ character varying(255),
    name_ character varying(255),
    key_ character varying(255) NOT NULL,
    version_ integer NOT NULL,
    deployment_id_ character varying(64),
    resource_name_ character varying(4000),
    dgrm_resource_name_ character varying(4000),
    description_ character varying(4000),
    has_start_form_key_ boolean,
    has_graphical_notation_ boolean,
    suspension_state_ integer,
    tenant_id_ character varying(255) DEFAULT ''::character varying
);


ALTER TABLE public.act_re_procdef OWNER TO alfresco;

--
-- Name: act_ru_event_subscr; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.act_ru_event_subscr (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    event_type_ character varying(255) NOT NULL,
    event_name_ character varying(255),
    execution_id_ character varying(64),
    proc_inst_id_ character varying(64),
    activity_id_ character varying(64),
    configuration_ character varying(255),
    created_ timestamp without time zone NOT NULL,
    proc_def_id_ character varying(64),
    tenant_id_ character varying(255) DEFAULT ''::character varying
);


ALTER TABLE public.act_ru_event_subscr OWNER TO alfresco;

--
-- Name: act_ru_execution; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.act_ru_execution (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    proc_inst_id_ character varying(64),
    business_key_ character varying(255),
    parent_id_ character varying(64),
    proc_def_id_ character varying(64),
    super_exec_ character varying(64),
    act_id_ character varying(255),
    is_active_ boolean,
    is_concurrent_ boolean,
    is_scope_ boolean,
    is_event_scope_ boolean,
    suspension_state_ integer,
    cached_ent_state_ integer,
    tenant_id_ character varying(255) DEFAULT ''::character varying,
    name_ character varying(255),
    lock_time_ timestamp without time zone
);


ALTER TABLE public.act_ru_execution OWNER TO alfresco;

--
-- Name: act_ru_identitylink; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.act_ru_identitylink (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    group_id_ character varying(255),
    type_ character varying(255),
    user_id_ character varying(255),
    task_id_ character varying(64),
    proc_inst_id_ character varying(64),
    proc_def_id_ character varying(64)
);


ALTER TABLE public.act_ru_identitylink OWNER TO alfresco;

--
-- Name: act_ru_job; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.act_ru_job (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    type_ character varying(255) NOT NULL,
    lock_exp_time_ timestamp without time zone,
    lock_owner_ character varying(255),
    exclusive_ boolean,
    execution_id_ character varying(64),
    process_instance_id_ character varying(64),
    proc_def_id_ character varying(64),
    retries_ integer,
    exception_stack_id_ character varying(64),
    exception_msg_ character varying(4000),
    duedate_ timestamp without time zone,
    repeat_ character varying(255),
    handler_type_ character varying(255),
    handler_cfg_ character varying(4000),
    tenant_id_ character varying(255) DEFAULT ''::character varying
);


ALTER TABLE public.act_ru_job OWNER TO alfresco;

--
-- Name: act_ru_task; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.act_ru_task (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    execution_id_ character varying(64),
    proc_inst_id_ character varying(64),
    proc_def_id_ character varying(64),
    name_ character varying(255),
    parent_task_id_ character varying(64),
    description_ character varying(4000),
    task_def_key_ character varying(255),
    owner_ character varying(255),
    assignee_ character varying(255),
    delegation_ character varying(64),
    priority_ integer,
    create_time_ timestamp without time zone,
    due_date_ timestamp without time zone,
    category_ character varying(255),
    suspension_state_ integer,
    tenant_id_ character varying(255) DEFAULT ''::character varying,
    form_key_ character varying(255)
);


ALTER TABLE public.act_ru_task OWNER TO alfresco;

--
-- Name: act_ru_variable; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.act_ru_variable (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    type_ character varying(255) NOT NULL,
    name_ character varying(255) NOT NULL,
    execution_id_ character varying(64),
    proc_inst_id_ character varying(64),
    task_id_ character varying(64),
    bytearray_id_ character varying(64),
    double_ double precision,
    long_ bigint,
    text_ character varying(4000),
    text2_ character varying(4000)
);


ALTER TABLE public.act_ru_variable OWNER TO alfresco;

--
-- Name: alf_access_control_entry; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_access_control_entry (
    id bigint NOT NULL,
    version bigint NOT NULL,
    permission_id bigint NOT NULL,
    authority_id bigint NOT NULL,
    allowed boolean NOT NULL,
    applies integer NOT NULL,
    context_id bigint
);


ALTER TABLE public.alf_access_control_entry OWNER TO alfresco;

--
-- Name: alf_access_control_entry_seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.alf_access_control_entry_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alf_access_control_entry_seq OWNER TO alfresco;

--
-- Name: alf_access_control_list; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_access_control_list (
    id bigint NOT NULL,
    version bigint NOT NULL,
    acl_id character varying(36) NOT NULL,
    latest boolean NOT NULL,
    acl_version bigint NOT NULL,
    inherits boolean NOT NULL,
    inherits_from bigint,
    type integer NOT NULL,
    inherited_acl bigint,
    is_versioned boolean NOT NULL,
    requires_version boolean NOT NULL,
    acl_change_set bigint
);


ALTER TABLE public.alf_access_control_list OWNER TO alfresco;

--
-- Name: alf_access_control_list_seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.alf_access_control_list_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alf_access_control_list_seq OWNER TO alfresco;

--
-- Name: alf_ace_context; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_ace_context (
    id bigint NOT NULL,
    version bigint NOT NULL,
    class_context character varying(1024),
    property_context character varying(1024),
    kvp_context character varying(1024)
);


ALTER TABLE public.alf_ace_context OWNER TO alfresco;

--
-- Name: alf_ace_context_seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.alf_ace_context_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alf_ace_context_seq OWNER TO alfresco;

--
-- Name: alf_acl_change_set; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_acl_change_set (
    id bigint NOT NULL,
    commit_time_ms bigint
);


ALTER TABLE public.alf_acl_change_set OWNER TO alfresco;

--
-- Name: alf_acl_change_set_seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.alf_acl_change_set_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alf_acl_change_set_seq OWNER TO alfresco;

--
-- Name: alf_acl_member; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_acl_member (
    id bigint NOT NULL,
    version bigint NOT NULL,
    acl_id bigint NOT NULL,
    ace_id bigint NOT NULL,
    pos integer NOT NULL
);


ALTER TABLE public.alf_acl_member OWNER TO alfresco;

--
-- Name: alf_acl_member_seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.alf_acl_member_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alf_acl_member_seq OWNER TO alfresco;

--
-- Name: alf_activity_feed; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_activity_feed (
    id bigint NOT NULL,
    post_id bigint,
    post_date timestamp without time zone NOT NULL,
    activity_summary character varying(1024),
    feed_user_id character varying(255),
    activity_type character varying(255) NOT NULL,
    site_network character varying(255),
    app_tool character varying(36),
    post_user_id character varying(255) NOT NULL,
    feed_date timestamp without time zone NOT NULL
);


ALTER TABLE public.alf_activity_feed OWNER TO alfresco;

--
-- Name: alf_activity_feed_control; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_activity_feed_control (
    id bigint NOT NULL,
    feed_user_id character varying(255) NOT NULL,
    site_network character varying(255),
    app_tool character varying(36),
    last_modified timestamp without time zone NOT NULL
);


ALTER TABLE public.alf_activity_feed_control OWNER TO alfresco;

--
-- Name: alf_activity_feed_control_seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.alf_activity_feed_control_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alf_activity_feed_control_seq OWNER TO alfresco;

--
-- Name: alf_activity_feed_seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.alf_activity_feed_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alf_activity_feed_seq OWNER TO alfresco;

--
-- Name: alf_activity_post; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_activity_post (
    sequence_id bigint NOT NULL,
    post_date timestamp without time zone NOT NULL,
    status character varying(10) NOT NULL,
    activity_data character varying(1024) NOT NULL,
    post_user_id character varying(255) NOT NULL,
    job_task_node integer NOT NULL,
    site_network character varying(255),
    app_tool character varying(36),
    activity_type character varying(255) NOT NULL,
    last_modified timestamp without time zone NOT NULL
);


ALTER TABLE public.alf_activity_post OWNER TO alfresco;

--
-- Name: alf_activity_post_seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.alf_activity_post_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alf_activity_post_seq OWNER TO alfresco;

--
-- Name: alf_applied_patch; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_applied_patch (
    id character varying(64) NOT NULL,
    description character varying(1024),
    fixes_from_schema integer,
    fixes_to_schema integer,
    applied_to_schema integer,
    target_schema integer,
    applied_on_date timestamp without time zone,
    applied_to_server character varying(64),
    was_executed boolean,
    succeeded boolean,
    report character varying(1024)
);


ALTER TABLE public.alf_applied_patch OWNER TO alfresco;

--
-- Name: alf_audit_app; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_audit_app (
    id bigint NOT NULL,
    version integer NOT NULL,
    app_name_id bigint NOT NULL,
    audit_model_id bigint NOT NULL,
    disabled_paths_id bigint NOT NULL
);


ALTER TABLE public.alf_audit_app OWNER TO alfresco;

--
-- Name: alf_audit_app_seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.alf_audit_app_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alf_audit_app_seq OWNER TO alfresco;

--
-- Name: alf_audit_entry; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_audit_entry (
    id bigint NOT NULL,
    audit_app_id bigint NOT NULL,
    audit_time bigint NOT NULL,
    audit_user_id bigint,
    audit_values_id bigint
);


ALTER TABLE public.alf_audit_entry OWNER TO alfresco;

--
-- Name: alf_audit_entry_seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.alf_audit_entry_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alf_audit_entry_seq OWNER TO alfresco;

--
-- Name: alf_audit_model; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_audit_model (
    id bigint NOT NULL,
    content_data_id bigint NOT NULL,
    content_crc bigint NOT NULL
);


ALTER TABLE public.alf_audit_model OWNER TO alfresco;

--
-- Name: alf_audit_model_seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.alf_audit_model_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alf_audit_model_seq OWNER TO alfresco;

--
-- Name: alf_auth_status; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_auth_status (
    id bigint NOT NULL,
    username character varying(100) NOT NULL,
    deleted boolean NOT NULL,
    authorized boolean NOT NULL,
    checksum bytea NOT NULL,
    authaction character varying(10) NOT NULL
);


ALTER TABLE public.alf_auth_status OWNER TO alfresco;

--
-- Name: alf_auth_status_seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.alf_auth_status_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alf_auth_status_seq OWNER TO alfresco;

--
-- Name: alf_authority; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_authority (
    id bigint NOT NULL,
    version bigint NOT NULL,
    authority character varying(100),
    crc bigint
);


ALTER TABLE public.alf_authority OWNER TO alfresco;

--
-- Name: alf_authority_alias; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_authority_alias (
    id bigint NOT NULL,
    version bigint NOT NULL,
    auth_id bigint NOT NULL,
    alias_id bigint NOT NULL
);


ALTER TABLE public.alf_authority_alias OWNER TO alfresco;

--
-- Name: alf_authority_alias_seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.alf_authority_alias_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alf_authority_alias_seq OWNER TO alfresco;

--
-- Name: alf_authority_seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.alf_authority_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alf_authority_seq OWNER TO alfresco;

--
-- Name: alf_child_assoc; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_child_assoc (
    id bigint NOT NULL,
    version bigint NOT NULL,
    parent_node_id bigint NOT NULL,
    type_qname_id bigint NOT NULL,
    child_node_name_crc bigint NOT NULL,
    child_node_name character varying(50) NOT NULL,
    child_node_id bigint NOT NULL,
    qname_ns_id bigint NOT NULL,
    qname_localname character varying(255) NOT NULL,
    qname_crc bigint NOT NULL,
    is_primary boolean,
    assoc_index integer
);


ALTER TABLE public.alf_child_assoc OWNER TO alfresco;

--
-- Name: alf_child_assoc_seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.alf_child_assoc_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alf_child_assoc_seq OWNER TO alfresco;

--
-- Name: alf_content_data; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_content_data (
    id bigint NOT NULL,
    version bigint NOT NULL,
    content_url_id bigint,
    content_mimetype_id bigint,
    content_encoding_id bigint,
    content_locale_id bigint
);


ALTER TABLE public.alf_content_data OWNER TO alfresco;

--
-- Name: alf_content_data_seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.alf_content_data_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alf_content_data_seq OWNER TO alfresco;

--
-- Name: alf_content_url; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_content_url (
    id bigint NOT NULL,
    content_url character varying(255) NOT NULL,
    content_url_short character varying(12) NOT NULL,
    content_url_crc bigint NOT NULL,
    content_size bigint NOT NULL,
    orphan_time bigint
);


ALTER TABLE public.alf_content_url OWNER TO alfresco;

--
-- Name: alf_content_url_enc_seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.alf_content_url_enc_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alf_content_url_enc_seq OWNER TO alfresco;

--
-- Name: alf_content_url_encryption; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_content_url_encryption (
    id bigint NOT NULL,
    content_url_id bigint NOT NULL,
    algorithm character varying(10) NOT NULL,
    key_size integer NOT NULL,
    encrypted_key bytea NOT NULL,
    master_keystore_id character varying(20) NOT NULL,
    master_key_alias character varying(15) NOT NULL,
    unencrypted_file_size bigint
);


ALTER TABLE public.alf_content_url_encryption OWNER TO alfresco;

--
-- Name: alf_content_url_seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.alf_content_url_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alf_content_url_seq OWNER TO alfresco;

--
-- Name: alf_encoding; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_encoding (
    id bigint NOT NULL,
    version bigint NOT NULL,
    encoding_str character varying(100) NOT NULL
);


ALTER TABLE public.alf_encoding OWNER TO alfresco;

--
-- Name: alf_encoding_seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.alf_encoding_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alf_encoding_seq OWNER TO alfresco;

--
-- Name: alf_locale; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_locale (
    id bigint NOT NULL,
    version bigint NOT NULL,
    locale_str character varying(20) NOT NULL
);


ALTER TABLE public.alf_locale OWNER TO alfresco;

--
-- Name: alf_locale_seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.alf_locale_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alf_locale_seq OWNER TO alfresco;

--
-- Name: alf_lock; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_lock (
    id bigint NOT NULL,
    version bigint NOT NULL,
    shared_resource_id bigint NOT NULL,
    excl_resource_id bigint NOT NULL,
    lock_token character varying(36) NOT NULL,
    start_time bigint NOT NULL,
    expiry_time bigint NOT NULL
);


ALTER TABLE public.alf_lock OWNER TO alfresco;

--
-- Name: alf_lock_resource; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_lock_resource (
    id bigint NOT NULL,
    version bigint NOT NULL,
    qname_ns_id bigint NOT NULL,
    qname_localname character varying(255) NOT NULL
);


ALTER TABLE public.alf_lock_resource OWNER TO alfresco;

--
-- Name: alf_lock_resource_seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.alf_lock_resource_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alf_lock_resource_seq OWNER TO alfresco;

--
-- Name: alf_lock_seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.alf_lock_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alf_lock_seq OWNER TO alfresco;

--
-- Name: alf_mimetype; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_mimetype (
    id bigint NOT NULL,
    version bigint NOT NULL,
    mimetype_str character varying(100) NOT NULL
);


ALTER TABLE public.alf_mimetype OWNER TO alfresco;

--
-- Name: alf_mimetype_seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.alf_mimetype_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alf_mimetype_seq OWNER TO alfresco;

--
-- Name: alf_namespace; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_namespace (
    id bigint NOT NULL,
    version bigint NOT NULL,
    uri character varying(100) NOT NULL
);


ALTER TABLE public.alf_namespace OWNER TO alfresco;

--
-- Name: alf_namespace_seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.alf_namespace_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alf_namespace_seq OWNER TO alfresco;

--
-- Name: alf_node; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_node (
    id bigint NOT NULL,
    version bigint NOT NULL,
    store_id bigint NOT NULL,
    uuid character varying(36) NOT NULL,
    transaction_id bigint NOT NULL,
    type_qname_id bigint NOT NULL,
    locale_id bigint NOT NULL,
    acl_id bigint,
    audit_creator character varying(255),
    audit_created character varying(30),
    audit_modifier character varying(255),
    audit_modified character varying(30),
    audit_accessed character varying(30)
);


ALTER TABLE public.alf_node OWNER TO alfresco;

--
-- Name: alf_node_aspects; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_node_aspects (
    node_id bigint NOT NULL,
    qname_id bigint NOT NULL
);


ALTER TABLE public.alf_node_aspects OWNER TO alfresco;

--
-- Name: alf_node_assoc; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_node_assoc (
    id bigint NOT NULL,
    version bigint NOT NULL,
    source_node_id bigint NOT NULL,
    target_node_id bigint NOT NULL,
    type_qname_id bigint NOT NULL,
    assoc_index bigint NOT NULL
);


ALTER TABLE public.alf_node_assoc OWNER TO alfresco;

--
-- Name: alf_node_assoc_seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.alf_node_assoc_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alf_node_assoc_seq OWNER TO alfresco;

--
-- Name: alf_node_properties; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_node_properties (
    node_id bigint NOT NULL,
    actual_type_n integer NOT NULL,
    persisted_type_n integer NOT NULL,
    boolean_value boolean,
    long_value bigint,
    float_value real,
    double_value double precision,
    string_value character varying(1024),
    serializable_value bytea,
    qname_id bigint NOT NULL,
    list_index integer NOT NULL,
    locale_id bigint NOT NULL
);


ALTER TABLE public.alf_node_properties OWNER TO alfresco;

--
-- Name: alf_node_seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.alf_node_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alf_node_seq OWNER TO alfresco;

--
-- Name: alf_permission; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_permission (
    id bigint NOT NULL,
    version bigint NOT NULL,
    type_qname_id bigint NOT NULL,
    name character varying(100) NOT NULL
);


ALTER TABLE public.alf_permission OWNER TO alfresco;

--
-- Name: alf_permission_seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.alf_permission_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alf_permission_seq OWNER TO alfresco;

--
-- Name: alf_prop_class; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_prop_class (
    id bigint NOT NULL,
    java_class_name character varying(255) NOT NULL,
    java_class_name_short character varying(32) NOT NULL,
    java_class_name_crc bigint NOT NULL
);


ALTER TABLE public.alf_prop_class OWNER TO alfresco;

--
-- Name: alf_prop_class_seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.alf_prop_class_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alf_prop_class_seq OWNER TO alfresco;

--
-- Name: alf_prop_date_value; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_prop_date_value (
    date_value bigint NOT NULL,
    full_year integer NOT NULL,
    half_of_year smallint NOT NULL,
    quarter_of_year smallint NOT NULL,
    month_of_year smallint NOT NULL,
    week_of_year smallint NOT NULL,
    week_of_month smallint NOT NULL,
    day_of_year integer NOT NULL,
    day_of_month smallint NOT NULL,
    day_of_week smallint NOT NULL
);


ALTER TABLE public.alf_prop_date_value OWNER TO alfresco;

--
-- Name: alf_prop_double_value; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_prop_double_value (
    id bigint NOT NULL,
    double_value double precision NOT NULL
);


ALTER TABLE public.alf_prop_double_value OWNER TO alfresco;

--
-- Name: alf_prop_double_value_seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.alf_prop_double_value_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alf_prop_double_value_seq OWNER TO alfresco;

--
-- Name: alf_prop_link; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_prop_link (
    root_prop_id bigint NOT NULL,
    prop_index bigint NOT NULL,
    contained_in bigint NOT NULL,
    key_prop_id bigint NOT NULL,
    value_prop_id bigint NOT NULL
);


ALTER TABLE public.alf_prop_link OWNER TO alfresco;

--
-- Name: alf_prop_root; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_prop_root (
    id bigint NOT NULL,
    version integer NOT NULL
);


ALTER TABLE public.alf_prop_root OWNER TO alfresco;

--
-- Name: alf_prop_root_seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.alf_prop_root_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alf_prop_root_seq OWNER TO alfresco;

--
-- Name: alf_prop_serializable_value; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_prop_serializable_value (
    id bigint NOT NULL,
    serializable_value bytea NOT NULL
);


ALTER TABLE public.alf_prop_serializable_value OWNER TO alfresco;

--
-- Name: alf_prop_serializable_value_seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.alf_prop_serializable_value_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alf_prop_serializable_value_seq OWNER TO alfresco;

--
-- Name: alf_prop_string_value; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_prop_string_value (
    id bigint NOT NULL,
    string_value character varying(1024) NOT NULL,
    string_end_lower character varying(16) NOT NULL,
    string_crc bigint NOT NULL
);


ALTER TABLE public.alf_prop_string_value OWNER TO alfresco;

--
-- Name: alf_prop_string_value_seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.alf_prop_string_value_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alf_prop_string_value_seq OWNER TO alfresco;

--
-- Name: alf_prop_unique_ctx; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_prop_unique_ctx (
    id bigint NOT NULL,
    version integer NOT NULL,
    value1_prop_id bigint NOT NULL,
    value2_prop_id bigint NOT NULL,
    value3_prop_id bigint NOT NULL,
    prop1_id bigint
);


ALTER TABLE public.alf_prop_unique_ctx OWNER TO alfresco;

--
-- Name: alf_prop_unique_ctx_seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.alf_prop_unique_ctx_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alf_prop_unique_ctx_seq OWNER TO alfresco;

--
-- Name: alf_prop_value; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_prop_value (
    id bigint NOT NULL,
    actual_type_id bigint NOT NULL,
    persisted_type smallint NOT NULL,
    long_value bigint NOT NULL
);


ALTER TABLE public.alf_prop_value OWNER TO alfresco;

--
-- Name: alf_prop_value_seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.alf_prop_value_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alf_prop_value_seq OWNER TO alfresco;

--
-- Name: alf_qname; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_qname (
    id bigint NOT NULL,
    version bigint NOT NULL,
    ns_id bigint NOT NULL,
    local_name character varying(200) NOT NULL
);


ALTER TABLE public.alf_qname OWNER TO alfresco;

--
-- Name: alf_qname_seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.alf_qname_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alf_qname_seq OWNER TO alfresco;

--
-- Name: alf_store; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_store (
    id bigint NOT NULL,
    version bigint NOT NULL,
    protocol character varying(50) NOT NULL,
    identifier character varying(100) NOT NULL,
    root_node_id bigint
);


ALTER TABLE public.alf_store OWNER TO alfresco;

--
-- Name: alf_store_seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.alf_store_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alf_store_seq OWNER TO alfresco;

--
-- Name: alf_subscriptions; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_subscriptions (
    user_node_id bigint NOT NULL,
    node_id bigint NOT NULL
);


ALTER TABLE public.alf_subscriptions OWNER TO alfresco;

--
-- Name: alf_tenant; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_tenant (
    tenant_domain character varying(75) NOT NULL,
    version bigint NOT NULL,
    enabled boolean NOT NULL,
    tenant_name character varying(75),
    content_root character varying(255),
    db_url character varying(255)
);


ALTER TABLE public.alf_tenant OWNER TO alfresco;

--
-- Name: alf_transaction; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_transaction (
    id bigint NOT NULL,
    version bigint NOT NULL,
    change_txn_id character varying(56) NOT NULL,
    commit_time_ms bigint
);


ALTER TABLE public.alf_transaction OWNER TO alfresco;

--
-- Name: alf_transaction_seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.alf_transaction_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alf_transaction_seq OWNER TO alfresco;

--
-- Name: alf_usage_delta; Type: TABLE; Schema: public; Owner: alfresco
--

CREATE TABLE public.alf_usage_delta (
    id bigint NOT NULL,
    version bigint NOT NULL,
    node_id bigint NOT NULL,
    delta_size bigint NOT NULL
);


ALTER TABLE public.alf_usage_delta OWNER TO alfresco;

--
-- Name: alf_usage_delta_seq; Type: SEQUENCE; Schema: public; Owner: alfresco
--

CREATE SEQUENCE public.alf_usage_delta_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alf_usage_delta_seq OWNER TO alfresco;

--
-- Name: act_evt_log log_nr_; Type: DEFAULT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_evt_log ALTER COLUMN log_nr_ SET DEFAULT nextval('public.act_evt_log_log_nr__seq'::regclass);


--
-- Data for Name: act_evt_log; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.act_evt_log (log_nr_, type_, proc_def_id_, proc_inst_id_, execution_id_, task_id_, time_stamp_, user_id_, data_, lock_owner_, lock_time_, is_processed_) FROM stdin;
\.
COPY public.act_evt_log (log_nr_, type_, proc_def_id_, proc_inst_id_, execution_id_, task_id_, time_stamp_, user_id_, data_, lock_owner_, lock_time_, is_processed_) FROM '$$PATH$$/3809.dat';

--
-- Data for Name: act_ge_bytearray; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.act_ge_bytearray (id_, rev_, name_, deployment_id_, bytes_, generated_) FROM stdin;
\.
COPY public.act_ge_bytearray (id_, rev_, name_, deployment_id_, bytes_, generated_) FROM '$$PATH$$/3798.dat';

--
-- Data for Name: act_ge_property; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.act_ge_property (name_, value_, rev_) FROM stdin;
\.
COPY public.act_ge_property (name_, value_, rev_) FROM '$$PATH$$/3797.dat';

--
-- Data for Name: act_hi_actinst; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.act_hi_actinst (id_, proc_def_id_, proc_inst_id_, execution_id_, act_id_, task_id_, call_proc_inst_id_, act_name_, act_type_, assignee_, start_time_, end_time_, duration_, tenant_id_) FROM stdin;
\.
COPY public.act_hi_actinst (id_, proc_def_id_, proc_inst_id_, execution_id_, act_id_, task_id_, call_proc_inst_id_, act_name_, act_type_, assignee_, start_time_, end_time_, duration_, tenant_id_) FROM '$$PATH$$/3812.dat';

--
-- Data for Name: act_hi_attachment; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.act_hi_attachment (id_, rev_, user_id_, name_, description_, type_, task_id_, proc_inst_id_, url_, content_id_, time_) FROM stdin;
\.
COPY public.act_hi_attachment (id_, rev_, user_id_, name_, description_, type_, task_id_, proc_inst_id_, url_, content_id_, time_) FROM '$$PATH$$/3817.dat';

--
-- Data for Name: act_hi_comment; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.act_hi_comment (id_, type_, time_, user_id_, task_id_, proc_inst_id_, action_, message_, full_msg_) FROM stdin;
\.
COPY public.act_hi_comment (id_, type_, time_, user_id_, task_id_, proc_inst_id_, action_, message_, full_msg_) FROM '$$PATH$$/3816.dat';

--
-- Data for Name: act_hi_detail; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.act_hi_detail (id_, type_, proc_inst_id_, execution_id_, task_id_, act_inst_id_, name_, var_type_, rev_, time_, bytearray_id_, double_, long_, text_, text2_) FROM stdin;
\.
COPY public.act_hi_detail (id_, type_, proc_inst_id_, execution_id_, task_id_, act_inst_id_, name_, var_type_, rev_, time_, bytearray_id_, double_, long_, text_, text2_) FROM '$$PATH$$/3815.dat';

--
-- Data for Name: act_hi_identitylink; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.act_hi_identitylink (id_, group_id_, type_, user_id_, task_id_, proc_inst_id_) FROM stdin;
\.
COPY public.act_hi_identitylink (id_, group_id_, type_, user_id_, task_id_, proc_inst_id_) FROM '$$PATH$$/3818.dat';

--
-- Data for Name: act_hi_procinst; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.act_hi_procinst (id_, proc_inst_id_, business_key_, proc_def_id_, start_time_, end_time_, duration_, start_user_id_, start_act_id_, end_act_id_, super_process_instance_id_, delete_reason_, tenant_id_, name_) FROM stdin;
\.
COPY public.act_hi_procinst (id_, proc_inst_id_, business_key_, proc_def_id_, start_time_, end_time_, duration_, start_user_id_, start_act_id_, end_act_id_, super_process_instance_id_, delete_reason_, tenant_id_, name_) FROM '$$PATH$$/3811.dat';

--
-- Data for Name: act_hi_taskinst; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.act_hi_taskinst (id_, proc_def_id_, task_def_key_, proc_inst_id_, execution_id_, name_, parent_task_id_, description_, owner_, assignee_, start_time_, claim_time_, end_time_, duration_, delete_reason_, priority_, due_date_, form_key_, category_, tenant_id_) FROM stdin;
\.
COPY public.act_hi_taskinst (id_, proc_def_id_, task_def_key_, proc_inst_id_, execution_id_, name_, parent_task_id_, description_, owner_, assignee_, start_time_, claim_time_, end_time_, duration_, delete_reason_, priority_, due_date_, form_key_, category_, tenant_id_) FROM '$$PATH$$/3813.dat';

--
-- Data for Name: act_hi_varinst; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.act_hi_varinst (id_, proc_inst_id_, execution_id_, task_id_, name_, var_type_, rev_, bytearray_id_, double_, long_, text_, text2_, create_time_, last_updated_time_) FROM stdin;
\.
COPY public.act_hi_varinst (id_, proc_inst_id_, execution_id_, task_id_, name_, var_type_, rev_, bytearray_id_, double_, long_, text_, text2_, create_time_, last_updated_time_) FROM '$$PATH$$/3814.dat';

--
-- Data for Name: act_id_group; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.act_id_group (id_, rev_, name_, type_) FROM stdin;
\.
COPY public.act_id_group (id_, rev_, name_, type_) FROM '$$PATH$$/3819.dat';

--
-- Data for Name: act_id_info; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.act_id_info (id_, rev_, user_id_, type_, key_, value_, password_, parent_id_) FROM stdin;
\.
COPY public.act_id_info (id_, rev_, user_id_, type_, key_, value_, password_, parent_id_) FROM '$$PATH$$/3822.dat';

--
-- Data for Name: act_id_membership; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.act_id_membership (user_id_, group_id_) FROM stdin;
\.
COPY public.act_id_membership (user_id_, group_id_) FROM '$$PATH$$/3820.dat';

--
-- Data for Name: act_id_user; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.act_id_user (id_, rev_, first_, last_, email_, pwd_, picture_id_) FROM stdin;
\.
COPY public.act_id_user (id_, rev_, first_, last_, email_, pwd_, picture_id_) FROM '$$PATH$$/3821.dat';

--
-- Data for Name: act_procdef_info; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.act_procdef_info (id_, proc_def_id_, rev_, info_json_id_) FROM stdin;
\.
COPY public.act_procdef_info (id_, proc_def_id_, rev_, info_json_id_) FROM '$$PATH$$/3810.dat';

--
-- Data for Name: act_re_deployment; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.act_re_deployment (id_, name_, category_, tenant_id_, deploy_time_) FROM stdin;
\.
COPY public.act_re_deployment (id_, name_, category_, tenant_id_, deploy_time_) FROM '$$PATH$$/3799.dat';

--
-- Data for Name: act_re_model; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.act_re_model (id_, rev_, name_, key_, category_, create_time_, last_update_time_, version_, meta_info_, deployment_id_, editor_source_value_id_, editor_source_extra_value_id_, tenant_id_) FROM stdin;
\.
COPY public.act_re_model (id_, rev_, name_, key_, category_, create_time_, last_update_time_, version_, meta_info_, deployment_id_, editor_source_value_id_, editor_source_extra_value_id_, tenant_id_) FROM '$$PATH$$/3800.dat';

--
-- Data for Name: act_re_procdef; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.act_re_procdef (id_, rev_, category_, name_, key_, version_, deployment_id_, resource_name_, dgrm_resource_name_, description_, has_start_form_key_, has_graphical_notation_, suspension_state_, tenant_id_) FROM stdin;
\.
COPY public.act_re_procdef (id_, rev_, category_, name_, key_, version_, deployment_id_, resource_name_, dgrm_resource_name_, description_, has_start_form_key_, has_graphical_notation_, suspension_state_, tenant_id_) FROM '$$PATH$$/3803.dat';

--
-- Data for Name: act_ru_event_subscr; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.act_ru_event_subscr (id_, rev_, event_type_, event_name_, execution_id_, proc_inst_id_, activity_id_, configuration_, created_, proc_def_id_, tenant_id_) FROM stdin;
\.
COPY public.act_ru_event_subscr (id_, rev_, event_type_, event_name_, execution_id_, proc_inst_id_, activity_id_, configuration_, created_, proc_def_id_, tenant_id_) FROM '$$PATH$$/3807.dat';

--
-- Data for Name: act_ru_execution; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.act_ru_execution (id_, rev_, proc_inst_id_, business_key_, parent_id_, proc_def_id_, super_exec_, act_id_, is_active_, is_concurrent_, is_scope_, is_event_scope_, suspension_state_, cached_ent_state_, tenant_id_, name_, lock_time_) FROM stdin;
\.
COPY public.act_ru_execution (id_, rev_, proc_inst_id_, business_key_, parent_id_, proc_def_id_, super_exec_, act_id_, is_active_, is_concurrent_, is_scope_, is_event_scope_, suspension_state_, cached_ent_state_, tenant_id_, name_, lock_time_) FROM '$$PATH$$/3801.dat';

--
-- Data for Name: act_ru_identitylink; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.act_ru_identitylink (id_, rev_, group_id_, type_, user_id_, task_id_, proc_inst_id_, proc_def_id_) FROM stdin;
\.
COPY public.act_ru_identitylink (id_, rev_, group_id_, type_, user_id_, task_id_, proc_inst_id_, proc_def_id_) FROM '$$PATH$$/3805.dat';

--
-- Data for Name: act_ru_job; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.act_ru_job (id_, rev_, type_, lock_exp_time_, lock_owner_, exclusive_, execution_id_, process_instance_id_, proc_def_id_, retries_, exception_stack_id_, exception_msg_, duedate_, repeat_, handler_type_, handler_cfg_, tenant_id_) FROM stdin;
\.
COPY public.act_ru_job (id_, rev_, type_, lock_exp_time_, lock_owner_, exclusive_, execution_id_, process_instance_id_, proc_def_id_, retries_, exception_stack_id_, exception_msg_, duedate_, repeat_, handler_type_, handler_cfg_, tenant_id_) FROM '$$PATH$$/3802.dat';

--
-- Data for Name: act_ru_task; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.act_ru_task (id_, rev_, execution_id_, proc_inst_id_, proc_def_id_, name_, parent_task_id_, description_, task_def_key_, owner_, assignee_, delegation_, priority_, create_time_, due_date_, category_, suspension_state_, tenant_id_, form_key_) FROM stdin;
\.
COPY public.act_ru_task (id_, rev_, execution_id_, proc_inst_id_, proc_def_id_, name_, parent_task_id_, description_, task_def_key_, owner_, assignee_, delegation_, priority_, create_time_, due_date_, category_, suspension_state_, tenant_id_, form_key_) FROM '$$PATH$$/3804.dat';

--
-- Data for Name: act_ru_variable; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.act_ru_variable (id_, rev_, type_, name_, execution_id_, proc_inst_id_, task_id_, bytearray_id_, double_, long_, text_, text2_) FROM stdin;
\.
COPY public.act_ru_variable (id_, rev_, type_, name_, execution_id_, proc_inst_id_, task_id_, bytearray_id_, double_, long_, text_, text2_) FROM '$$PATH$$/3806.dat';

--
-- Data for Name: alf_access_control_entry; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_access_control_entry (id, version, permission_id, authority_id, allowed, applies, context_id) FROM stdin;
\.
COPY public.alf_access_control_entry (id, version, permission_id, authority_id, allowed, applies, context_id) FROM '$$PATH$$/3728.dat';

--
-- Data for Name: alf_access_control_list; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_access_control_list (id, version, acl_id, latest, acl_version, inherits, inherits_from, type, inherited_acl, is_versioned, requires_version, acl_change_set) FROM stdin;
\.
COPY public.alf_access_control_list (id, version, acl_id, latest, acl_version, inherits, inherits_from, type, inherited_acl, is_versioned, requires_version, acl_change_set) FROM '$$PATH$$/3732.dat';

--
-- Data for Name: alf_ace_context; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_ace_context (id, version, class_context, property_context, kvp_context) FROM stdin;
\.
COPY public.alf_ace_context (id, version, class_context, property_context, kvp_context) FROM '$$PATH$$/3724.dat';

--
-- Data for Name: alf_acl_change_set; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_acl_change_set (id, commit_time_ms) FROM stdin;
\.
COPY public.alf_acl_change_set (id, commit_time_ms) FROM '$$PATH$$/3730.dat';

--
-- Data for Name: alf_acl_member; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_acl_member (id, version, acl_id, ace_id, pos) FROM stdin;
\.
COPY public.alf_acl_member (id, version, acl_id, ace_id, pos) FROM '$$PATH$$/3734.dat';

--
-- Data for Name: alf_activity_feed; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_activity_feed (id, post_id, post_date, activity_summary, feed_user_id, activity_type, site_network, app_tool, post_user_id, feed_date) FROM stdin;
\.
COPY public.alf_activity_feed (id, post_id, post_date, activity_summary, feed_user_id, activity_type, site_network, app_tool, post_user_id, feed_date) FROM '$$PATH$$/3786.dat';

--
-- Data for Name: alf_activity_feed_control; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_activity_feed_control (id, feed_user_id, site_network, app_tool, last_modified) FROM stdin;
\.
COPY public.alf_activity_feed_control (id, feed_user_id, site_network, app_tool, last_modified) FROM '$$PATH$$/3788.dat';

--
-- Data for Name: alf_activity_post; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_activity_post (sequence_id, post_date, status, activity_data, post_user_id, job_task_node, site_network, app_tool, activity_type, last_modified) FROM stdin;
\.
COPY public.alf_activity_post (sequence_id, post_date, status, activity_data, post_user_id, job_task_node, site_network, app_tool, activity_type, last_modified) FROM '$$PATH$$/3790.dat';

--
-- Data for Name: alf_applied_patch; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_applied_patch (id, description, fixes_from_schema, fixes_to_schema, applied_to_schema, target_schema, applied_on_date, applied_to_server, was_executed, succeeded, report) FROM stdin;
\.
COPY public.alf_applied_patch (id, description, fixes_from_schema, fixes_to_schema, applied_to_schema, target_schema, applied_on_date, applied_to_server, was_executed, succeeded, report) FROM '$$PATH$$/3714.dat';

--
-- Data for Name: alf_audit_app; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_audit_app (id, version, app_name_id, audit_model_id, disabled_paths_id) FROM stdin;
\.
COPY public.alf_audit_app (id, version, app_name_id, audit_model_id, disabled_paths_id) FROM '$$PATH$$/3782.dat';

--
-- Data for Name: alf_audit_entry; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_audit_entry (id, audit_app_id, audit_time, audit_user_id, audit_values_id) FROM stdin;
\.
COPY public.alf_audit_entry (id, audit_app_id, audit_time, audit_user_id, audit_values_id) FROM '$$PATH$$/3784.dat';

--
-- Data for Name: alf_audit_model; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_audit_model (id, content_data_id, content_crc) FROM stdin;
\.
COPY public.alf_audit_model (id, content_data_id, content_crc) FROM '$$PATH$$/3780.dat';

--
-- Data for Name: alf_auth_status; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_auth_status (id, username, deleted, authorized, checksum, authaction) FROM stdin;
\.
COPY public.alf_auth_status (id, username, deleted, authorized, checksum, authaction) FROM '$$PATH$$/3796.dat';

--
-- Data for Name: alf_authority; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_authority (id, version, authority, crc) FROM stdin;
\.
COPY public.alf_authority (id, version, authority, crc) FROM '$$PATH$$/3726.dat';

--
-- Data for Name: alf_authority_alias; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_authority_alias (id, version, auth_id, alias_id) FROM stdin;
\.
COPY public.alf_authority_alias (id, version, auth_id, alias_id) FROM '$$PATH$$/3736.dat';

--
-- Data for Name: alf_child_assoc; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_child_assoc (id, version, parent_node_id, type_qname_id, child_node_name_crc, child_node_name, child_node_id, qname_ns_id, qname_localname, qname_crc, is_primary, assoc_index) FROM stdin;
\.
COPY public.alf_child_assoc (id, version, parent_node_id, type_qname_id, child_node_name_crc, child_node_name, child_node_id, qname_ns_id, qname_localname, qname_crc, is_primary, assoc_index) FROM '$$PATH$$/3744.dat';

--
-- Data for Name: alf_content_data; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_content_data (id, version, content_url_id, content_mimetype_id, content_encoding_id, content_locale_id) FROM stdin;
\.
COPY public.alf_content_data (id, version, content_url_id, content_mimetype_id, content_encoding_id, content_locale_id) FROM '$$PATH$$/3760.dat';

--
-- Data for Name: alf_content_url; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_content_url (id, content_url, content_url_short, content_url_crc, content_size, orphan_time) FROM stdin;
\.
COPY public.alf_content_url (id, content_url, content_url_short, content_url_crc, content_size, orphan_time) FROM '$$PATH$$/3758.dat';

--
-- Data for Name: alf_content_url_encryption; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_content_url_encryption (id, content_url_id, algorithm, key_size, encrypted_key, master_keystore_id, master_key_alias, unencrypted_file_size) FROM stdin;
\.
COPY public.alf_content_url_encryption (id, content_url_id, algorithm, key_size, encrypted_key, master_keystore_id, master_key_alias, unencrypted_file_size) FROM '$$PATH$$/3778.dat';

--
-- Data for Name: alf_encoding; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_encoding (id, version, encoding_str) FROM stdin;
\.
COPY public.alf_encoding (id, version, encoding_str) FROM '$$PATH$$/3756.dat';

--
-- Data for Name: alf_locale; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_locale (id, version, locale_str) FROM stdin;
\.
COPY public.alf_locale (id, version, locale_str) FROM '$$PATH$$/3716.dat';

--
-- Data for Name: alf_lock; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_lock (id, version, shared_resource_id, excl_resource_id, lock_token, start_time, expiry_time) FROM stdin;
\.
COPY public.alf_lock (id, version, shared_resource_id, excl_resource_id, lock_token, start_time, expiry_time) FROM '$$PATH$$/3752.dat';

--
-- Data for Name: alf_lock_resource; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_lock_resource (id, version, qname_ns_id, qname_localname) FROM stdin;
\.
COPY public.alf_lock_resource (id, version, qname_ns_id, qname_localname) FROM '$$PATH$$/3750.dat';

--
-- Data for Name: alf_mimetype; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_mimetype (id, version, mimetype_str) FROM stdin;
\.
COPY public.alf_mimetype (id, version, mimetype_str) FROM '$$PATH$$/3754.dat';

--
-- Data for Name: alf_namespace; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_namespace (id, version, uri) FROM stdin;
\.
COPY public.alf_namespace (id, version, uri) FROM '$$PATH$$/3718.dat';

--
-- Data for Name: alf_node; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_node (id, version, store_id, uuid, transaction_id, type_qname_id, locale_id, acl_id, audit_creator, audit_created, audit_modifier, audit_modified, audit_accessed) FROM stdin;
\.
COPY public.alf_node (id, version, store_id, uuid, transaction_id, type_qname_id, locale_id, acl_id, audit_creator, audit_created, audit_modifier, audit_modified, audit_accessed) FROM '$$PATH$$/3742.dat';

--
-- Data for Name: alf_node_aspects; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_node_aspects (node_id, qname_id) FROM stdin;
\.
COPY public.alf_node_aspects (node_id, qname_id) FROM '$$PATH$$/3745.dat';

--
-- Data for Name: alf_node_assoc; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_node_assoc (id, version, source_node_id, target_node_id, type_qname_id, assoc_index) FROM stdin;
\.
COPY public.alf_node_assoc (id, version, source_node_id, target_node_id, type_qname_id, assoc_index) FROM '$$PATH$$/3747.dat';

--
-- Data for Name: alf_node_properties; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_node_properties (node_id, actual_type_n, persisted_type_n, boolean_value, long_value, float_value, double_value, string_value, serializable_value, qname_id, list_index, locale_id) FROM stdin;
\.
COPY public.alf_node_properties (node_id, actual_type_n, persisted_type_n, boolean_value, long_value, float_value, double_value, string_value, serializable_value, qname_id, list_index, locale_id) FROM '$$PATH$$/3748.dat';

--
-- Data for Name: alf_permission; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_permission (id, version, type_qname_id, name) FROM stdin;
\.
COPY public.alf_permission (id, version, type_qname_id, name) FROM '$$PATH$$/3722.dat';

--
-- Data for Name: alf_prop_class; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_prop_class (id, java_class_name, java_class_name_short, java_class_name_crc) FROM stdin;
\.
COPY public.alf_prop_class (id, java_class_name, java_class_name_short, java_class_name_crc) FROM '$$PATH$$/3762.dat';

--
-- Data for Name: alf_prop_date_value; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_prop_date_value (date_value, full_year, half_of_year, quarter_of_year, month_of_year, week_of_year, week_of_month, day_of_year, day_of_month, day_of_week) FROM stdin;
\.
COPY public.alf_prop_date_value (date_value, full_year, half_of_year, quarter_of_year, month_of_year, week_of_year, week_of_month, day_of_year, day_of_month, day_of_week) FROM '$$PATH$$/3763.dat';

--
-- Data for Name: alf_prop_double_value; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_prop_double_value (id, double_value) FROM stdin;
\.
COPY public.alf_prop_double_value (id, double_value) FROM '$$PATH$$/3765.dat';

--
-- Data for Name: alf_prop_link; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_prop_link (root_prop_id, prop_index, contained_in, key_prop_id, value_prop_id) FROM stdin;
\.
COPY public.alf_prop_link (root_prop_id, prop_index, contained_in, key_prop_id, value_prop_id) FROM '$$PATH$$/3774.dat';

--
-- Data for Name: alf_prop_root; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_prop_root (id, version) FROM stdin;
\.
COPY public.alf_prop_root (id, version) FROM '$$PATH$$/3773.dat';

--
-- Data for Name: alf_prop_serializable_value; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_prop_serializable_value (id, serializable_value) FROM stdin;
\.
COPY public.alf_prop_serializable_value (id, serializable_value) FROM '$$PATH$$/3769.dat';

--
-- Data for Name: alf_prop_string_value; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_prop_string_value (id, string_value, string_end_lower, string_crc) FROM stdin;
\.
COPY public.alf_prop_string_value (id, string_value, string_end_lower, string_crc) FROM '$$PATH$$/3767.dat';

--
-- Data for Name: alf_prop_unique_ctx; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_prop_unique_ctx (id, version, value1_prop_id, value2_prop_id, value3_prop_id, prop1_id) FROM stdin;
\.
COPY public.alf_prop_unique_ctx (id, version, value1_prop_id, value2_prop_id, value3_prop_id, prop1_id) FROM '$$PATH$$/3776.dat';

--
-- Data for Name: alf_prop_value; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_prop_value (id, actual_type_id, persisted_type, long_value) FROM stdin;
\.
COPY public.alf_prop_value (id, actual_type_id, persisted_type, long_value) FROM '$$PATH$$/3771.dat';

--
-- Data for Name: alf_qname; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_qname (id, version, ns_id, local_name) FROM stdin;
\.
COPY public.alf_qname (id, version, ns_id, local_name) FROM '$$PATH$$/3720.dat';

--
-- Data for Name: alf_store; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_store (id, version, protocol, identifier, root_node_id) FROM stdin;
\.
COPY public.alf_store (id, version, protocol, identifier, root_node_id) FROM '$$PATH$$/3740.dat';

--
-- Data for Name: alf_subscriptions; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_subscriptions (user_node_id, node_id) FROM stdin;
\.
COPY public.alf_subscriptions (user_node_id, node_id) FROM '$$PATH$$/3793.dat';

--
-- Data for Name: alf_tenant; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_tenant (tenant_domain, version, enabled, tenant_name, content_root, db_url) FROM stdin;
\.
COPY public.alf_tenant (tenant_domain, version, enabled, tenant_name, content_root, db_url) FROM '$$PATH$$/3794.dat';

--
-- Data for Name: alf_transaction; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_transaction (id, version, change_txn_id, commit_time_ms) FROM stdin;
\.
COPY public.alf_transaction (id, version, change_txn_id, commit_time_ms) FROM '$$PATH$$/3738.dat';

--
-- Data for Name: alf_usage_delta; Type: TABLE DATA; Schema: public; Owner: alfresco
--

COPY public.alf_usage_delta (id, version, node_id, delta_size) FROM stdin;
\.
COPY public.alf_usage_delta (id, version, node_id, delta_size) FROM '$$PATH$$/3792.dat';

--
-- Name: act_evt_log_log_nr__seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.act_evt_log_log_nr__seq', 1, false);


--
-- Name: alf_access_control_entry_seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.alf_access_control_entry_seq', 74, true);


--
-- Name: alf_access_control_list_seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.alf_access_control_list_seq', 363, true);


--
-- Name: alf_ace_context_seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.alf_ace_context_seq', 1, false);


--
-- Name: alf_acl_change_set_seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.alf_acl_change_set_seq', 61, true);


--
-- Name: alf_acl_member_seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.alf_acl_member_seq', 983, true);


--
-- Name: alf_activity_feed_control_seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.alf_activity_feed_control_seq', 1, false);


--
-- Name: alf_activity_feed_seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.alf_activity_feed_seq', 2400, true);


--
-- Name: alf_activity_post_seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.alf_activity_post_seq', 48, true);


--
-- Name: alf_audit_app_seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.alf_audit_app_seq', 1, true);


--
-- Name: alf_audit_entry_seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.alf_audit_entry_seq', 20, true);


--
-- Name: alf_audit_model_seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.alf_audit_model_seq', 3, true);


--
-- Name: alf_auth_status_seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.alf_auth_status_seq', 1, false);


--
-- Name: alf_authority_alias_seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.alf_authority_alias_seq', 1, false);


--
-- Name: alf_authority_seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.alf_authority_seq', 65, true);


--
-- Name: alf_child_assoc_seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.alf_child_assoc_seq', 2305, true);


--
-- Name: alf_content_data_seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.alf_content_data_seq', 1256, true);


--
-- Name: alf_content_url_enc_seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.alf_content_url_enc_seq', 1, false);


--
-- Name: alf_content_url_seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.alf_content_url_seq', 973, true);


--
-- Name: alf_encoding_seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.alf_encoding_seq', 3, true);


--
-- Name: alf_locale_seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.alf_locale_seq', 4, true);


--
-- Name: alf_lock_resource_seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.alf_lock_resource_seq', 30, true);


--
-- Name: alf_lock_seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.alf_lock_seq', 37, true);


--
-- Name: alf_mimetype_seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.alf_mimetype_seq', 15, true);


--
-- Name: alf_namespace_seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.alf_namespace_seq', 21, true);


--
-- Name: alf_node_assoc_seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.alf_node_assoc_seq', 297, true);


--
-- Name: alf_node_seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.alf_node_seq', 2233, true);


--
-- Name: alf_permission_seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.alf_permission_seq', 12, true);


--
-- Name: alf_prop_class_seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.alf_prop_class_seq', 6, true);


--
-- Name: alf_prop_double_value_seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.alf_prop_double_value_seq', 1, false);


--
-- Name: alf_prop_root_seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.alf_prop_root_seq', 36, true);


--
-- Name: alf_prop_serializable_value_seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.alf_prop_serializable_value_seq', 1, true);


--
-- Name: alf_prop_string_value_seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.alf_prop_string_value_seq', 24, true);


--
-- Name: alf_prop_unique_ctx_seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.alf_prop_unique_ctx_seq', 7, true);


--
-- Name: alf_prop_value_seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.alf_prop_value_seq', 31, true);


--
-- Name: alf_qname_seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.alf_qname_seq', 255, true);


--
-- Name: alf_store_seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.alf_store_seq', 6, true);


--
-- Name: alf_transaction_seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.alf_transaction_seq', 592, true);


--
-- Name: alf_usage_delta_seq; Type: SEQUENCE SET; Schema: public; Owner: alfresco
--

SELECT pg_catalog.setval('public.alf_usage_delta_seq', 1, false);


--
-- Name: act_evt_log act_evt_log_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_evt_log
    ADD CONSTRAINT act_evt_log_pkey PRIMARY KEY (log_nr_);


--
-- Name: act_ge_bytearray act_ge_bytearray_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_ge_bytearray
    ADD CONSTRAINT act_ge_bytearray_pkey PRIMARY KEY (id_);


--
-- Name: act_ge_property act_ge_property_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_ge_property
    ADD CONSTRAINT act_ge_property_pkey PRIMARY KEY (name_);


--
-- Name: act_hi_actinst act_hi_actinst_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_hi_actinst
    ADD CONSTRAINT act_hi_actinst_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_attachment act_hi_attachment_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_hi_attachment
    ADD CONSTRAINT act_hi_attachment_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_comment act_hi_comment_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_hi_comment
    ADD CONSTRAINT act_hi_comment_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_detail act_hi_detail_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_hi_detail
    ADD CONSTRAINT act_hi_detail_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_identitylink act_hi_identitylink_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_hi_identitylink
    ADD CONSTRAINT act_hi_identitylink_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_procinst act_hi_procinst_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_hi_procinst
    ADD CONSTRAINT act_hi_procinst_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_procinst act_hi_procinst_proc_inst_id__key; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_hi_procinst
    ADD CONSTRAINT act_hi_procinst_proc_inst_id__key UNIQUE (proc_inst_id_);


--
-- Name: act_hi_taskinst act_hi_taskinst_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_hi_taskinst
    ADD CONSTRAINT act_hi_taskinst_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_varinst act_hi_varinst_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_hi_varinst
    ADD CONSTRAINT act_hi_varinst_pkey PRIMARY KEY (id_);


--
-- Name: act_id_group act_id_group_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_id_group
    ADD CONSTRAINT act_id_group_pkey PRIMARY KEY (id_);


--
-- Name: act_id_info act_id_info_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_id_info
    ADD CONSTRAINT act_id_info_pkey PRIMARY KEY (id_);


--
-- Name: act_id_membership act_id_membership_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_id_membership
    ADD CONSTRAINT act_id_membership_pkey PRIMARY KEY (user_id_, group_id_);


--
-- Name: act_id_user act_id_user_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_id_user
    ADD CONSTRAINT act_id_user_pkey PRIMARY KEY (id_);


--
-- Name: act_procdef_info act_procdef_info_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_procdef_info
    ADD CONSTRAINT act_procdef_info_pkey PRIMARY KEY (id_);


--
-- Name: act_re_deployment act_re_deployment_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_re_deployment
    ADD CONSTRAINT act_re_deployment_pkey PRIMARY KEY (id_);


--
-- Name: act_re_model act_re_model_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_re_model
    ADD CONSTRAINT act_re_model_pkey PRIMARY KEY (id_);


--
-- Name: act_re_procdef act_re_procdef_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_re_procdef
    ADD CONSTRAINT act_re_procdef_pkey PRIMARY KEY (id_);


--
-- Name: act_ru_event_subscr act_ru_event_subscr_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_ru_event_subscr
    ADD CONSTRAINT act_ru_event_subscr_pkey PRIMARY KEY (id_);


--
-- Name: act_ru_execution act_ru_execution_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_ru_execution
    ADD CONSTRAINT act_ru_execution_pkey PRIMARY KEY (id_);


--
-- Name: act_ru_identitylink act_ru_identitylink_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_ru_identitylink
    ADD CONSTRAINT act_ru_identitylink_pkey PRIMARY KEY (id_);


--
-- Name: act_ru_job act_ru_job_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_ru_job
    ADD CONSTRAINT act_ru_job_pkey PRIMARY KEY (id_);


--
-- Name: act_ru_task act_ru_task_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_ru_task
    ADD CONSTRAINT act_ru_task_pkey PRIMARY KEY (id_);


--
-- Name: act_ru_variable act_ru_variable_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_ru_variable
    ADD CONSTRAINT act_ru_variable_pkey PRIMARY KEY (id_);


--
-- Name: act_procdef_info act_uniq_info_procdef; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_procdef_info
    ADD CONSTRAINT act_uniq_info_procdef UNIQUE (proc_def_id_);


--
-- Name: act_re_procdef act_uniq_procdef; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_re_procdef
    ADD CONSTRAINT act_uniq_procdef UNIQUE (key_, version_, tenant_id_);


--
-- Name: alf_access_control_entry alf_access_control_entry_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_access_control_entry
    ADD CONSTRAINT alf_access_control_entry_pkey PRIMARY KEY (id);


--
-- Name: alf_access_control_list alf_access_control_list_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_access_control_list
    ADD CONSTRAINT alf_access_control_list_pkey PRIMARY KEY (id);


--
-- Name: alf_ace_context alf_ace_context_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_ace_context
    ADD CONSTRAINT alf_ace_context_pkey PRIMARY KEY (id);


--
-- Name: alf_acl_change_set alf_acl_change_set_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_acl_change_set
    ADD CONSTRAINT alf_acl_change_set_pkey PRIMARY KEY (id);


--
-- Name: alf_acl_member alf_acl_member_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_acl_member
    ADD CONSTRAINT alf_acl_member_pkey PRIMARY KEY (id);


--
-- Name: alf_activity_feed_control alf_activity_feed_control_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_activity_feed_control
    ADD CONSTRAINT alf_activity_feed_control_pkey PRIMARY KEY (id);


--
-- Name: alf_activity_feed alf_activity_feed_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_activity_feed
    ADD CONSTRAINT alf_activity_feed_pkey PRIMARY KEY (id);


--
-- Name: alf_activity_post alf_activity_post_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_activity_post
    ADD CONSTRAINT alf_activity_post_pkey PRIMARY KEY (sequence_id);


--
-- Name: alf_applied_patch alf_applied_patch_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_applied_patch
    ADD CONSTRAINT alf_applied_patch_pkey PRIMARY KEY (id);


--
-- Name: alf_audit_app alf_audit_app_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_audit_app
    ADD CONSTRAINT alf_audit_app_pkey PRIMARY KEY (id);


--
-- Name: alf_audit_entry alf_audit_entry_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_audit_entry
    ADD CONSTRAINT alf_audit_entry_pkey PRIMARY KEY (id);


--
-- Name: alf_audit_model alf_audit_model_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_audit_model
    ADD CONSTRAINT alf_audit_model_pkey PRIMARY KEY (id);


--
-- Name: alf_auth_status alf_auth_status_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_auth_status
    ADD CONSTRAINT alf_auth_status_pkey PRIMARY KEY (id);


--
-- Name: alf_authority_alias alf_authority_alias_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_authority_alias
    ADD CONSTRAINT alf_authority_alias_pkey PRIMARY KEY (id);


--
-- Name: alf_authority alf_authority_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_authority
    ADD CONSTRAINT alf_authority_pkey PRIMARY KEY (id);


--
-- Name: alf_child_assoc alf_child_assoc_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_child_assoc
    ADD CONSTRAINT alf_child_assoc_pkey PRIMARY KEY (id);


--
-- Name: alf_content_data alf_content_data_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_content_data
    ADD CONSTRAINT alf_content_data_pkey PRIMARY KEY (id);


--
-- Name: alf_content_url_encryption alf_content_url_encryption_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_content_url_encryption
    ADD CONSTRAINT alf_content_url_encryption_pkey PRIMARY KEY (id);


--
-- Name: alf_content_url alf_content_url_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_content_url
    ADD CONSTRAINT alf_content_url_pkey PRIMARY KEY (id);


--
-- Name: alf_encoding alf_encoding_encoding_str_key; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_encoding
    ADD CONSTRAINT alf_encoding_encoding_str_key UNIQUE (encoding_str);


--
-- Name: alf_encoding alf_encoding_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_encoding
    ADD CONSTRAINT alf_encoding_pkey PRIMARY KEY (id);


--
-- Name: alf_locale alf_locale_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_locale
    ADD CONSTRAINT alf_locale_pkey PRIMARY KEY (id);


--
-- Name: alf_lock alf_lock_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_lock
    ADD CONSTRAINT alf_lock_pkey PRIMARY KEY (id);


--
-- Name: alf_lock_resource alf_lock_resource_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_lock_resource
    ADD CONSTRAINT alf_lock_resource_pkey PRIMARY KEY (id);


--
-- Name: alf_mimetype alf_mimetype_mimetype_str_key; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_mimetype
    ADD CONSTRAINT alf_mimetype_mimetype_str_key UNIQUE (mimetype_str);


--
-- Name: alf_mimetype alf_mimetype_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_mimetype
    ADD CONSTRAINT alf_mimetype_pkey PRIMARY KEY (id);


--
-- Name: alf_namespace alf_namespace_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_namespace
    ADD CONSTRAINT alf_namespace_pkey PRIMARY KEY (id);


--
-- Name: alf_node_aspects alf_node_aspects_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_node_aspects
    ADD CONSTRAINT alf_node_aspects_pkey PRIMARY KEY (node_id, qname_id);


--
-- Name: alf_node_assoc alf_node_assoc_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_node_assoc
    ADD CONSTRAINT alf_node_assoc_pkey PRIMARY KEY (id);


--
-- Name: alf_node alf_node_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_node
    ADD CONSTRAINT alf_node_pkey PRIMARY KEY (id);


--
-- Name: alf_node_properties alf_node_properties_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_node_properties
    ADD CONSTRAINT alf_node_properties_pkey PRIMARY KEY (node_id, qname_id, list_index, locale_id);


--
-- Name: alf_permission alf_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_permission
    ADD CONSTRAINT alf_permission_pkey PRIMARY KEY (id);


--
-- Name: alf_prop_class alf_prop_class_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_prop_class
    ADD CONSTRAINT alf_prop_class_pkey PRIMARY KEY (id);


--
-- Name: alf_prop_date_value alf_prop_date_value_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_prop_date_value
    ADD CONSTRAINT alf_prop_date_value_pkey PRIMARY KEY (date_value);


--
-- Name: alf_prop_double_value alf_prop_double_value_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_prop_double_value
    ADD CONSTRAINT alf_prop_double_value_pkey PRIMARY KEY (id);


--
-- Name: alf_prop_link alf_prop_link_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_prop_link
    ADD CONSTRAINT alf_prop_link_pkey PRIMARY KEY (root_prop_id, contained_in, prop_index);


--
-- Name: alf_prop_root alf_prop_root_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_prop_root
    ADD CONSTRAINT alf_prop_root_pkey PRIMARY KEY (id);


--
-- Name: alf_prop_serializable_value alf_prop_serializable_value_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_prop_serializable_value
    ADD CONSTRAINT alf_prop_serializable_value_pkey PRIMARY KEY (id);


--
-- Name: alf_prop_string_value alf_prop_string_value_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_prop_string_value
    ADD CONSTRAINT alf_prop_string_value_pkey PRIMARY KEY (id);


--
-- Name: alf_prop_unique_ctx alf_prop_unique_ctx_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_prop_unique_ctx
    ADD CONSTRAINT alf_prop_unique_ctx_pkey PRIMARY KEY (id);


--
-- Name: alf_prop_value alf_prop_value_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_prop_value
    ADD CONSTRAINT alf_prop_value_pkey PRIMARY KEY (id);


--
-- Name: alf_qname alf_qname_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_qname
    ADD CONSTRAINT alf_qname_pkey PRIMARY KEY (id);


--
-- Name: alf_store alf_store_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_store
    ADD CONSTRAINT alf_store_pkey PRIMARY KEY (id);


--
-- Name: alf_subscriptions alf_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_subscriptions
    ADD CONSTRAINT alf_subscriptions_pkey PRIMARY KEY (user_node_id, node_id);


--
-- Name: alf_tenant alf_tenant_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_tenant
    ADD CONSTRAINT alf_tenant_pkey PRIMARY KEY (tenant_domain);


--
-- Name: alf_transaction alf_transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_transaction
    ADD CONSTRAINT alf_transaction_pkey PRIMARY KEY (id);


--
-- Name: alf_usage_delta alf_usage_delta_pkey; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_usage_delta
    ADD CONSTRAINT alf_usage_delta_pkey PRIMARY KEY (id);


--
-- Name: alf_audit_app idx_alf_aud_app_an; Type: CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_audit_app
    ADD CONSTRAINT idx_alf_aud_app_an UNIQUE (app_name_id);


--
-- Name: acl_id; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE UNIQUE INDEX acl_id ON public.alf_access_control_list USING btree (acl_id, latest, acl_version);


--
-- Name: aclm_acl_id; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE UNIQUE INDEX aclm_acl_id ON public.alf_acl_member USING btree (acl_id, ace_id, pos);


--
-- Name: act_idx_athrz_procedef; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_athrz_procedef ON public.act_ru_identitylink USING btree (proc_def_id_);


--
-- Name: act_idx_bytear_depl; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_bytear_depl ON public.act_ge_bytearray USING btree (deployment_id_);


--
-- Name: act_idx_event_subscr; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_event_subscr ON public.act_ru_event_subscr USING btree (execution_id_);


--
-- Name: act_idx_event_subscr_config_; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_event_subscr_config_ ON public.act_ru_event_subscr USING btree (configuration_);


--
-- Name: act_idx_exe_parent; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_exe_parent ON public.act_ru_execution USING btree (parent_id_);


--
-- Name: act_idx_exe_procdef; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_exe_procdef ON public.act_ru_execution USING btree (proc_def_id_);


--
-- Name: act_idx_exe_procinst; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_exe_procinst ON public.act_ru_execution USING btree (proc_inst_id_);


--
-- Name: act_idx_exe_super; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_exe_super ON public.act_ru_execution USING btree (super_exec_);


--
-- Name: act_idx_exec_buskey; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_exec_buskey ON public.act_ru_execution USING btree (business_key_);


--
-- Name: act_idx_hi_act_inst_end; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_hi_act_inst_end ON public.act_hi_actinst USING btree (end_time_);


--
-- Name: act_idx_hi_act_inst_exec; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_hi_act_inst_exec ON public.act_hi_actinst USING btree (execution_id_, act_id_);


--
-- Name: act_idx_hi_act_inst_procinst; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_hi_act_inst_procinst ON public.act_hi_actinst USING btree (proc_inst_id_, act_id_);


--
-- Name: act_idx_hi_act_inst_start; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_hi_act_inst_start ON public.act_hi_actinst USING btree (start_time_);


--
-- Name: act_idx_hi_detail_act_inst; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_hi_detail_act_inst ON public.act_hi_detail USING btree (act_inst_id_);


--
-- Name: act_idx_hi_detail_name; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_hi_detail_name ON public.act_hi_detail USING btree (name_);


--
-- Name: act_idx_hi_detail_proc_inst; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_hi_detail_proc_inst ON public.act_hi_detail USING btree (proc_inst_id_);


--
-- Name: act_idx_hi_detail_task_id; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_hi_detail_task_id ON public.act_hi_detail USING btree (task_id_);


--
-- Name: act_idx_hi_detail_time; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_hi_detail_time ON public.act_hi_detail USING btree (time_);


--
-- Name: act_idx_hi_ident_lnk_procinst; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_hi_ident_lnk_procinst ON public.act_hi_identitylink USING btree (proc_inst_id_);


--
-- Name: act_idx_hi_ident_lnk_task; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_hi_ident_lnk_task ON public.act_hi_identitylink USING btree (task_id_);


--
-- Name: act_idx_hi_ident_lnk_user; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_hi_ident_lnk_user ON public.act_hi_identitylink USING btree (user_id_);


--
-- Name: act_idx_hi_pro_i_buskey; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_hi_pro_i_buskey ON public.act_hi_procinst USING btree (business_key_);


--
-- Name: act_idx_hi_pro_inst_end; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_hi_pro_inst_end ON public.act_hi_procinst USING btree (end_time_);


--
-- Name: act_idx_hi_procvar_name_type; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_hi_procvar_name_type ON public.act_hi_varinst USING btree (name_, var_type_);


--
-- Name: act_idx_hi_procvar_proc_inst; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_hi_procvar_proc_inst ON public.act_hi_varinst USING btree (proc_inst_id_);


--
-- Name: act_idx_hi_procvar_task_id; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_hi_procvar_task_id ON public.act_hi_varinst USING btree (task_id_);


--
-- Name: act_idx_hi_task_inst_procinst; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_hi_task_inst_procinst ON public.act_hi_taskinst USING btree (proc_inst_id_);


--
-- Name: act_idx_ident_lnk_group; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_ident_lnk_group ON public.act_ru_identitylink USING btree (group_id_);


--
-- Name: act_idx_ident_lnk_user; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_ident_lnk_user ON public.act_ru_identitylink USING btree (user_id_);


--
-- Name: act_idx_idl_procinst; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_idl_procinst ON public.act_ru_identitylink USING btree (proc_inst_id_);


--
-- Name: act_idx_job_exception; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_job_exception ON public.act_ru_job USING btree (exception_stack_id_);


--
-- Name: act_idx_memb_group; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_memb_group ON public.act_id_membership USING btree (group_id_);


--
-- Name: act_idx_memb_user; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_memb_user ON public.act_id_membership USING btree (user_id_);


--
-- Name: act_idx_model_deployment; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_model_deployment ON public.act_re_model USING btree (deployment_id_);


--
-- Name: act_idx_model_source; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_model_source ON public.act_re_model USING btree (editor_source_value_id_);


--
-- Name: act_idx_model_source_extra; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_model_source_extra ON public.act_re_model USING btree (editor_source_extra_value_id_);


--
-- Name: act_idx_procdef_info_json; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_procdef_info_json ON public.act_procdef_info USING btree (info_json_id_);


--
-- Name: act_idx_procdef_info_proc; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_procdef_info_proc ON public.act_procdef_info USING btree (proc_def_id_);


--
-- Name: act_idx_task_create; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_task_create ON public.act_ru_task USING btree (create_time_);


--
-- Name: act_idx_task_exec; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_task_exec ON public.act_ru_task USING btree (execution_id_);


--
-- Name: act_idx_task_procdef; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_task_procdef ON public.act_ru_task USING btree (proc_def_id_);


--
-- Name: act_idx_task_procinst; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_task_procinst ON public.act_ru_task USING btree (proc_inst_id_);


--
-- Name: act_idx_tskass_task; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_tskass_task ON public.act_ru_identitylink USING btree (task_id_);


--
-- Name: act_idx_var_bytearray; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_var_bytearray ON public.act_ru_variable USING btree (bytearray_id_);


--
-- Name: act_idx_var_exe; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_var_exe ON public.act_ru_variable USING btree (execution_id_);


--
-- Name: act_idx_var_procinst; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_var_procinst ON public.act_ru_variable USING btree (proc_inst_id_);


--
-- Name: act_idx_variable_task_id; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX act_idx_variable_task_id ON public.act_ru_variable USING btree (task_id_);


--
-- Name: auth_id; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE UNIQUE INDEX auth_id ON public.alf_authority_alias USING btree (auth_id, alias_id);


--
-- Name: authority; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE UNIQUE INDEX authority ON public.alf_authority USING btree (authority, crc);


--
-- Name: feed_feeduserid_idx; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX feed_feeduserid_idx ON public.alf_activity_feed USING btree (feed_user_id);


--
-- Name: feed_postdate_idx; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX feed_postdate_idx ON public.alf_activity_feed USING btree (post_date);


--
-- Name: feed_postuserid_idx; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX feed_postuserid_idx ON public.alf_activity_feed USING btree (post_user_id);


--
-- Name: feed_sitenetwork_idx; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX feed_sitenetwork_idx ON public.alf_activity_feed USING btree (site_network);


--
-- Name: feedctrl_feeduserid_idx; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX feedctrl_feeduserid_idx ON public.alf_activity_feed_control USING btree (feed_user_id);


--
-- Name: fk_alf_ace_auth; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_ace_auth ON public.alf_access_control_entry USING btree (authority_id);


--
-- Name: fk_alf_ace_ctx; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_ace_ctx ON public.alf_access_control_entry USING btree (context_id);


--
-- Name: fk_alf_ace_perm; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_ace_perm ON public.alf_access_control_entry USING btree (permission_id);


--
-- Name: fk_alf_acl_acs; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_acl_acs ON public.alf_access_control_list USING btree (acl_change_set);


--
-- Name: fk_alf_aclm_ace; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_aclm_ace ON public.alf_acl_member USING btree (ace_id);


--
-- Name: fk_alf_aclm_acl; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_aclm_acl ON public.alf_acl_member USING btree (acl_id);


--
-- Name: fk_alf_aud_app_dis; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_aud_app_dis ON public.alf_audit_app USING btree (disabled_paths_id);


--
-- Name: fk_alf_aud_app_mod; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_aud_app_mod ON public.alf_audit_app USING btree (audit_model_id);


--
-- Name: fk_alf_aud_ent_app; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_aud_ent_app ON public.alf_audit_entry USING btree (audit_app_id);


--
-- Name: fk_alf_aud_ent_pro; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_aud_ent_pro ON public.alf_audit_entry USING btree (audit_values_id);


--
-- Name: fk_alf_aud_ent_use; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_aud_ent_use ON public.alf_audit_entry USING btree (audit_user_id);


--
-- Name: fk_alf_aud_mod_cd; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_aud_mod_cd ON public.alf_audit_model USING btree (content_data_id);


--
-- Name: fk_alf_autha_ali; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_autha_ali ON public.alf_authority_alias USING btree (alias_id);


--
-- Name: fk_alf_autha_aut; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_autha_aut ON public.alf_authority_alias USING btree (auth_id);


--
-- Name: fk_alf_cass_cnode; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_cass_cnode ON public.alf_child_assoc USING btree (child_node_id);


--
-- Name: fk_alf_cass_qnns; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_cass_qnns ON public.alf_child_assoc USING btree (qname_ns_id);


--
-- Name: fk_alf_cass_tqn; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_cass_tqn ON public.alf_child_assoc USING btree (type_qname_id);


--
-- Name: fk_alf_cont_enc; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_cont_enc ON public.alf_content_data USING btree (content_encoding_id);


--
-- Name: fk_alf_cont_loc; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_cont_loc ON public.alf_content_data USING btree (content_locale_id);


--
-- Name: fk_alf_cont_mim; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_cont_mim ON public.alf_content_data USING btree (content_mimetype_id);


--
-- Name: fk_alf_cont_url; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_cont_url ON public.alf_content_data USING btree (content_url_id);


--
-- Name: fk_alf_lock_excl; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_lock_excl ON public.alf_lock USING btree (excl_resource_id);


--
-- Name: fk_alf_nasp_n; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_nasp_n ON public.alf_node_aspects USING btree (node_id);


--
-- Name: fk_alf_nasp_qn; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_nasp_qn ON public.alf_node_aspects USING btree (qname_id);


--
-- Name: fk_alf_nass_snode; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_nass_snode ON public.alf_node_assoc USING btree (source_node_id, type_qname_id, assoc_index);


--
-- Name: fk_alf_nass_tnode; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_nass_tnode ON public.alf_node_assoc USING btree (target_node_id, type_qname_id);


--
-- Name: fk_alf_nass_tqn; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_nass_tqn ON public.alf_node_assoc USING btree (type_qname_id);


--
-- Name: fk_alf_node_acl; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_node_acl ON public.alf_node USING btree (acl_id);


--
-- Name: fk_alf_node_loc; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_node_loc ON public.alf_node USING btree (locale_id);


--
-- Name: fk_alf_node_store; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_node_store ON public.alf_node USING btree (store_id);


--
-- Name: fk_alf_nprop_loc; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_nprop_loc ON public.alf_node_properties USING btree (locale_id);


--
-- Name: fk_alf_nprop_n; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_nprop_n ON public.alf_node_properties USING btree (node_id);


--
-- Name: fk_alf_nprop_qn; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_nprop_qn ON public.alf_node_properties USING btree (qname_id);


--
-- Name: fk_alf_perm_tqn; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_perm_tqn ON public.alf_permission USING btree (type_qname_id);


--
-- Name: fk_alf_propln_key; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_propln_key ON public.alf_prop_link USING btree (key_prop_id);


--
-- Name: fk_alf_propln_val; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_propln_val ON public.alf_prop_link USING btree (value_prop_id);


--
-- Name: fk_alf_propuctx_p1; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_propuctx_p1 ON public.alf_prop_unique_ctx USING btree (prop1_id);


--
-- Name: fk_alf_propuctx_v2; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_propuctx_v2 ON public.alf_prop_unique_ctx USING btree (value2_prop_id);


--
-- Name: fk_alf_propuctx_v3; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_propuctx_v3 ON public.alf_prop_unique_ctx USING btree (value3_prop_id);


--
-- Name: fk_alf_store_root; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_store_root ON public.alf_store USING btree (root_node_id);


--
-- Name: fk_alf_sub_node; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_sub_node ON public.alf_subscriptions USING btree (node_id);


--
-- Name: fk_alf_usaged_n; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX fk_alf_usaged_n ON public.alf_usage_delta USING btree (node_id);


--
-- Name: idx_alf_acl_acs; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX idx_alf_acl_acs ON public.alf_access_control_list USING btree (acl_change_set, id);


--
-- Name: idx_alf_acl_inh; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX idx_alf_acl_inh ON public.alf_access_control_list USING btree (inherits, inherits_from);


--
-- Name: idx_alf_acs_ctms; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX idx_alf_acs_ctms ON public.alf_acl_change_set USING btree (commit_time_ms, id);


--
-- Name: idx_alf_aud_ent_tm; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX idx_alf_aud_ent_tm ON public.alf_audit_entry USING btree (audit_time);


--
-- Name: idx_alf_aud_mod_cr; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE UNIQUE INDEX idx_alf_aud_mod_cr ON public.alf_audit_model USING btree (content_crc);


--
-- Name: idx_alf_auth_action; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX idx_alf_auth_action ON public.alf_auth_status USING btree (authaction);


--
-- Name: idx_alf_auth_aut; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX idx_alf_auth_aut ON public.alf_authority USING btree (authority);


--
-- Name: idx_alf_auth_deleted; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX idx_alf_auth_deleted ON public.alf_auth_status USING btree (deleted);


--
-- Name: idx_alf_auth_usr_stat; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE UNIQUE INDEX idx_alf_auth_usr_stat ON public.alf_auth_status USING btree (username, authorized);


--
-- Name: idx_alf_cass_pnode; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX idx_alf_cass_pnode ON public.alf_child_assoc USING btree (parent_node_id, assoc_index, id);


--
-- Name: idx_alf_cass_pri; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX idx_alf_cass_pri ON public.alf_child_assoc USING btree (parent_node_id, is_primary, child_node_id);


--
-- Name: idx_alf_cass_qncrc; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX idx_alf_cass_qncrc ON public.alf_child_assoc USING btree (qname_crc, type_qname_id, parent_node_id);


--
-- Name: idx_alf_cont_enc_mka; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX idx_alf_cont_enc_mka ON public.alf_content_url_encryption USING btree (master_key_alias);


--
-- Name: idx_alf_cont_enc_url; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE UNIQUE INDEX idx_alf_cont_enc_url ON public.alf_content_url_encryption USING btree (content_url_id);


--
-- Name: idx_alf_conturl_cr; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE UNIQUE INDEX idx_alf_conturl_cr ON public.alf_content_url USING btree (content_url_short, content_url_crc);


--
-- Name: idx_alf_conturl_ot; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX idx_alf_conturl_ot ON public.alf_content_url USING btree (orphan_time);


--
-- Name: idx_alf_conturl_sz; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX idx_alf_conturl_sz ON public.alf_content_url USING btree (content_size, id);


--
-- Name: idx_alf_lock_key; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE UNIQUE INDEX idx_alf_lock_key ON public.alf_lock USING btree (shared_resource_id, excl_resource_id);


--
-- Name: idx_alf_lockr_key; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE UNIQUE INDEX idx_alf_lockr_key ON public.alf_lock_resource USING btree (qname_ns_id, qname_localname);


--
-- Name: idx_alf_node_cor; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX idx_alf_node_cor ON public.alf_node USING btree (audit_creator, store_id, type_qname_id, id);


--
-- Name: idx_alf_node_crd; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX idx_alf_node_crd ON public.alf_node USING btree (audit_created, store_id, type_qname_id, id);


--
-- Name: idx_alf_node_mdq; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX idx_alf_node_mdq ON public.alf_node USING btree (store_id, type_qname_id, id);


--
-- Name: idx_alf_node_mod; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX idx_alf_node_mod ON public.alf_node USING btree (audit_modified, store_id, type_qname_id, id);


--
-- Name: idx_alf_node_mor; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX idx_alf_node_mor ON public.alf_node USING btree (audit_modifier, store_id, type_qname_id, id);


--
-- Name: idx_alf_node_tqn; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX idx_alf_node_tqn ON public.alf_node USING btree (type_qname_id, store_id, id);


--
-- Name: idx_alf_node_txn; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX idx_alf_node_txn ON public.alf_node USING btree (transaction_id);


--
-- Name: idx_alf_node_txn_type; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX idx_alf_node_txn_type ON public.alf_node USING btree (transaction_id, type_qname_id);


--
-- Name: idx_alf_node_ver; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX idx_alf_node_ver ON public.alf_node USING btree (version);


--
-- Name: idx_alf_nprop_b; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX idx_alf_nprop_b ON public.alf_node_properties USING btree (qname_id, boolean_value, node_id);


--
-- Name: idx_alf_nprop_d; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX idx_alf_nprop_d ON public.alf_node_properties USING btree (qname_id, double_value, node_id);


--
-- Name: idx_alf_nprop_f; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX idx_alf_nprop_f ON public.alf_node_properties USING btree (qname_id, float_value, node_id);


--
-- Name: idx_alf_nprop_l; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX idx_alf_nprop_l ON public.alf_node_properties USING btree (qname_id, long_value, node_id);


--
-- Name: idx_alf_nprop_s; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX idx_alf_nprop_s ON public.alf_node_properties USING btree (qname_id, string_value, node_id);


--
-- Name: idx_alf_propc_clas; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX idx_alf_propc_clas ON public.alf_prop_class USING btree (java_class_name);


--
-- Name: idx_alf_propc_crc; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE UNIQUE INDEX idx_alf_propc_crc ON public.alf_prop_class USING btree (java_class_name_crc, java_class_name_short);


--
-- Name: idx_alf_propd_val; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE UNIQUE INDEX idx_alf_propd_val ON public.alf_prop_double_value USING btree (double_value);


--
-- Name: idx_alf_propdt_dt; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX idx_alf_propdt_dt ON public.alf_prop_date_value USING btree (full_year, month_of_year, day_of_month);


--
-- Name: idx_alf_propln_for; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX idx_alf_propln_for ON public.alf_prop_link USING btree (root_prop_id, key_prop_id, value_prop_id);


--
-- Name: idx_alf_props_crc; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE UNIQUE INDEX idx_alf_props_crc ON public.alf_prop_string_value USING btree (string_end_lower, string_crc);


--
-- Name: idx_alf_props_str; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX idx_alf_props_str ON public.alf_prop_string_value USING btree (string_value);


--
-- Name: idx_alf_propuctx; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE UNIQUE INDEX idx_alf_propuctx ON public.alf_prop_unique_ctx USING btree (value1_prop_id, value2_prop_id, value3_prop_id);


--
-- Name: idx_alf_propv_act; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE UNIQUE INDEX idx_alf_propv_act ON public.alf_prop_value USING btree (actual_type_id, long_value);


--
-- Name: idx_alf_propv_per; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX idx_alf_propv_per ON public.alf_prop_value USING btree (persisted_type, long_value);


--
-- Name: idx_alf_txn_ctms; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX idx_alf_txn_ctms ON public.alf_transaction USING btree (commit_time_ms, id);


--
-- Name: idx_alf_txn_ctms_sc; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX idx_alf_txn_ctms_sc ON public.alf_transaction USING btree (commit_time_ms);


--
-- Name: idx_alf_txn_id_ctms; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX idx_alf_txn_id_ctms ON public.alf_transaction USING btree (id, commit_time_ms);


--
-- Name: locale_str; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE UNIQUE INDEX locale_str ON public.alf_locale USING btree (locale_str);


--
-- Name: ns_id; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE UNIQUE INDEX ns_id ON public.alf_qname USING btree (ns_id, local_name);


--
-- Name: parent_node_id; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE UNIQUE INDEX parent_node_id ON public.alf_child_assoc USING btree (parent_node_id, type_qname_id, child_node_name_crc, child_node_name);


--
-- Name: permission_id; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE UNIQUE INDEX permission_id ON public.alf_access_control_entry USING btree (permission_id, authority_id, allowed, applies);


--
-- Name: post_jobtasknode_idx; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX post_jobtasknode_idx ON public.alf_activity_post USING btree (job_task_node);


--
-- Name: post_status_idx; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE INDEX post_status_idx ON public.alf_activity_post USING btree (status);


--
-- Name: protocol; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE UNIQUE INDEX protocol ON public.alf_store USING btree (protocol, identifier);


--
-- Name: source_node_id; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE UNIQUE INDEX source_node_id ON public.alf_node_assoc USING btree (source_node_id, target_node_id, type_qname_id);


--
-- Name: store_id; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE UNIQUE INDEX store_id ON public.alf_node USING btree (store_id, uuid);


--
-- Name: type_qname_id; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE UNIQUE INDEX type_qname_id ON public.alf_permission USING btree (type_qname_id, name);


--
-- Name: uri; Type: INDEX; Schema: public; Owner: alfresco
--

CREATE UNIQUE INDEX uri ON public.alf_namespace USING btree (uri);


--
-- Name: act_ru_identitylink act_fk_athrz_procedef; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_ru_identitylink
    ADD CONSTRAINT act_fk_athrz_procedef FOREIGN KEY (proc_def_id_) REFERENCES public.act_re_procdef(id_);


--
-- Name: act_ge_bytearray act_fk_bytearr_depl; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_ge_bytearray
    ADD CONSTRAINT act_fk_bytearr_depl FOREIGN KEY (deployment_id_) REFERENCES public.act_re_deployment(id_);


--
-- Name: act_ru_event_subscr act_fk_event_exec; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_ru_event_subscr
    ADD CONSTRAINT act_fk_event_exec FOREIGN KEY (execution_id_) REFERENCES public.act_ru_execution(id_);


--
-- Name: act_ru_execution act_fk_exe_parent; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_ru_execution
    ADD CONSTRAINT act_fk_exe_parent FOREIGN KEY (parent_id_) REFERENCES public.act_ru_execution(id_);


--
-- Name: act_ru_execution act_fk_exe_procdef; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_ru_execution
    ADD CONSTRAINT act_fk_exe_procdef FOREIGN KEY (proc_def_id_) REFERENCES public.act_re_procdef(id_);


--
-- Name: act_ru_execution act_fk_exe_procinst; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_ru_execution
    ADD CONSTRAINT act_fk_exe_procinst FOREIGN KEY (proc_inst_id_) REFERENCES public.act_ru_execution(id_);


--
-- Name: act_ru_execution act_fk_exe_super; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_ru_execution
    ADD CONSTRAINT act_fk_exe_super FOREIGN KEY (super_exec_) REFERENCES public.act_ru_execution(id_);


--
-- Name: act_ru_identitylink act_fk_idl_procinst; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_ru_identitylink
    ADD CONSTRAINT act_fk_idl_procinst FOREIGN KEY (proc_inst_id_) REFERENCES public.act_ru_execution(id_);


--
-- Name: act_procdef_info act_fk_info_json_ba; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_procdef_info
    ADD CONSTRAINT act_fk_info_json_ba FOREIGN KEY (info_json_id_) REFERENCES public.act_ge_bytearray(id_);


--
-- Name: act_procdef_info act_fk_info_procdef; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_procdef_info
    ADD CONSTRAINT act_fk_info_procdef FOREIGN KEY (proc_def_id_) REFERENCES public.act_re_procdef(id_);


--
-- Name: act_ru_job act_fk_job_exception; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_ru_job
    ADD CONSTRAINT act_fk_job_exception FOREIGN KEY (exception_stack_id_) REFERENCES public.act_ge_bytearray(id_);


--
-- Name: act_id_membership act_fk_memb_group; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_id_membership
    ADD CONSTRAINT act_fk_memb_group FOREIGN KEY (group_id_) REFERENCES public.act_id_group(id_);


--
-- Name: act_id_membership act_fk_memb_user; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_id_membership
    ADD CONSTRAINT act_fk_memb_user FOREIGN KEY (user_id_) REFERENCES public.act_id_user(id_);


--
-- Name: act_re_model act_fk_model_deployment; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_re_model
    ADD CONSTRAINT act_fk_model_deployment FOREIGN KEY (deployment_id_) REFERENCES public.act_re_deployment(id_);


--
-- Name: act_re_model act_fk_model_source; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_re_model
    ADD CONSTRAINT act_fk_model_source FOREIGN KEY (editor_source_value_id_) REFERENCES public.act_ge_bytearray(id_);


--
-- Name: act_re_model act_fk_model_source_extra; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_re_model
    ADD CONSTRAINT act_fk_model_source_extra FOREIGN KEY (editor_source_extra_value_id_) REFERENCES public.act_ge_bytearray(id_);


--
-- Name: act_ru_task act_fk_task_exe; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_ru_task
    ADD CONSTRAINT act_fk_task_exe FOREIGN KEY (execution_id_) REFERENCES public.act_ru_execution(id_);


--
-- Name: act_ru_task act_fk_task_procdef; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_ru_task
    ADD CONSTRAINT act_fk_task_procdef FOREIGN KEY (proc_def_id_) REFERENCES public.act_re_procdef(id_);


--
-- Name: act_ru_task act_fk_task_procinst; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_ru_task
    ADD CONSTRAINT act_fk_task_procinst FOREIGN KEY (proc_inst_id_) REFERENCES public.act_ru_execution(id_);


--
-- Name: act_ru_identitylink act_fk_tskass_task; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_ru_identitylink
    ADD CONSTRAINT act_fk_tskass_task FOREIGN KEY (task_id_) REFERENCES public.act_ru_task(id_);


--
-- Name: act_ru_variable act_fk_var_bytearray; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_ru_variable
    ADD CONSTRAINT act_fk_var_bytearray FOREIGN KEY (bytearray_id_) REFERENCES public.act_ge_bytearray(id_);


--
-- Name: act_ru_variable act_fk_var_exe; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_ru_variable
    ADD CONSTRAINT act_fk_var_exe FOREIGN KEY (execution_id_) REFERENCES public.act_ru_execution(id_);


--
-- Name: act_ru_variable act_fk_var_procinst; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.act_ru_variable
    ADD CONSTRAINT act_fk_var_procinst FOREIGN KEY (proc_inst_id_) REFERENCES public.act_ru_execution(id_);


--
-- Name: alf_access_control_entry fk_alf_ace_auth; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_access_control_entry
    ADD CONSTRAINT fk_alf_ace_auth FOREIGN KEY (authority_id) REFERENCES public.alf_authority(id);


--
-- Name: alf_access_control_entry fk_alf_ace_ctx; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_access_control_entry
    ADD CONSTRAINT fk_alf_ace_ctx FOREIGN KEY (context_id) REFERENCES public.alf_ace_context(id);


--
-- Name: alf_access_control_entry fk_alf_ace_perm; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_access_control_entry
    ADD CONSTRAINT fk_alf_ace_perm FOREIGN KEY (permission_id) REFERENCES public.alf_permission(id);


--
-- Name: alf_access_control_list fk_alf_acl_acs; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_access_control_list
    ADD CONSTRAINT fk_alf_acl_acs FOREIGN KEY (acl_change_set) REFERENCES public.alf_acl_change_set(id);


--
-- Name: alf_acl_member fk_alf_aclm_ace; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_acl_member
    ADD CONSTRAINT fk_alf_aclm_ace FOREIGN KEY (ace_id) REFERENCES public.alf_access_control_entry(id);


--
-- Name: alf_acl_member fk_alf_aclm_acl; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_acl_member
    ADD CONSTRAINT fk_alf_aclm_acl FOREIGN KEY (acl_id) REFERENCES public.alf_access_control_list(id);


--
-- Name: alf_audit_app fk_alf_aud_app_an; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_audit_app
    ADD CONSTRAINT fk_alf_aud_app_an FOREIGN KEY (app_name_id) REFERENCES public.alf_prop_value(id);


--
-- Name: alf_audit_app fk_alf_aud_app_dis; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_audit_app
    ADD CONSTRAINT fk_alf_aud_app_dis FOREIGN KEY (disabled_paths_id) REFERENCES public.alf_prop_root(id);


--
-- Name: alf_audit_app fk_alf_aud_app_mod; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_audit_app
    ADD CONSTRAINT fk_alf_aud_app_mod FOREIGN KEY (audit_model_id) REFERENCES public.alf_audit_model(id) ON DELETE CASCADE;


--
-- Name: alf_audit_entry fk_alf_aud_ent_app; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_audit_entry
    ADD CONSTRAINT fk_alf_aud_ent_app FOREIGN KEY (audit_app_id) REFERENCES public.alf_audit_app(id) ON DELETE CASCADE;


--
-- Name: alf_audit_entry fk_alf_aud_ent_pro; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_audit_entry
    ADD CONSTRAINT fk_alf_aud_ent_pro FOREIGN KEY (audit_values_id) REFERENCES public.alf_prop_root(id);


--
-- Name: alf_audit_entry fk_alf_aud_ent_use; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_audit_entry
    ADD CONSTRAINT fk_alf_aud_ent_use FOREIGN KEY (audit_user_id) REFERENCES public.alf_prop_value(id);


--
-- Name: alf_audit_model fk_alf_aud_mod_cd; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_audit_model
    ADD CONSTRAINT fk_alf_aud_mod_cd FOREIGN KEY (content_data_id) REFERENCES public.alf_content_data(id);


--
-- Name: alf_authority_alias fk_alf_autha_ali; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_authority_alias
    ADD CONSTRAINT fk_alf_autha_ali FOREIGN KEY (alias_id) REFERENCES public.alf_authority(id);


--
-- Name: alf_authority_alias fk_alf_autha_aut; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_authority_alias
    ADD CONSTRAINT fk_alf_autha_aut FOREIGN KEY (auth_id) REFERENCES public.alf_authority(id);


--
-- Name: alf_child_assoc fk_alf_cass_cnode; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_child_assoc
    ADD CONSTRAINT fk_alf_cass_cnode FOREIGN KEY (child_node_id) REFERENCES public.alf_node(id);


--
-- Name: alf_child_assoc fk_alf_cass_pnode; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_child_assoc
    ADD CONSTRAINT fk_alf_cass_pnode FOREIGN KEY (parent_node_id) REFERENCES public.alf_node(id);


--
-- Name: alf_child_assoc fk_alf_cass_qnns; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_child_assoc
    ADD CONSTRAINT fk_alf_cass_qnns FOREIGN KEY (qname_ns_id) REFERENCES public.alf_namespace(id);


--
-- Name: alf_child_assoc fk_alf_cass_tqn; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_child_assoc
    ADD CONSTRAINT fk_alf_cass_tqn FOREIGN KEY (type_qname_id) REFERENCES public.alf_qname(id);


--
-- Name: alf_content_data fk_alf_cont_enc; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_content_data
    ADD CONSTRAINT fk_alf_cont_enc FOREIGN KEY (content_encoding_id) REFERENCES public.alf_encoding(id);


--
-- Name: alf_content_url_encryption fk_alf_cont_enc_url; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_content_url_encryption
    ADD CONSTRAINT fk_alf_cont_enc_url FOREIGN KEY (content_url_id) REFERENCES public.alf_content_url(id) ON DELETE CASCADE;


--
-- Name: alf_content_data fk_alf_cont_loc; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_content_data
    ADD CONSTRAINT fk_alf_cont_loc FOREIGN KEY (content_locale_id) REFERENCES public.alf_locale(id);


--
-- Name: alf_content_data fk_alf_cont_mim; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_content_data
    ADD CONSTRAINT fk_alf_cont_mim FOREIGN KEY (content_mimetype_id) REFERENCES public.alf_mimetype(id);


--
-- Name: alf_content_data fk_alf_cont_url; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_content_data
    ADD CONSTRAINT fk_alf_cont_url FOREIGN KEY (content_url_id) REFERENCES public.alf_content_url(id);


--
-- Name: alf_lock fk_alf_lock_excl; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_lock
    ADD CONSTRAINT fk_alf_lock_excl FOREIGN KEY (excl_resource_id) REFERENCES public.alf_lock_resource(id);


--
-- Name: alf_lock fk_alf_lock_shared; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_lock
    ADD CONSTRAINT fk_alf_lock_shared FOREIGN KEY (shared_resource_id) REFERENCES public.alf_lock_resource(id);


--
-- Name: alf_lock_resource fk_alf_lockr_ns; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_lock_resource
    ADD CONSTRAINT fk_alf_lockr_ns FOREIGN KEY (qname_ns_id) REFERENCES public.alf_namespace(id);


--
-- Name: alf_node_aspects fk_alf_nasp_n; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_node_aspects
    ADD CONSTRAINT fk_alf_nasp_n FOREIGN KEY (node_id) REFERENCES public.alf_node(id);


--
-- Name: alf_node_aspects fk_alf_nasp_qn; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_node_aspects
    ADD CONSTRAINT fk_alf_nasp_qn FOREIGN KEY (qname_id) REFERENCES public.alf_qname(id);


--
-- Name: alf_node_assoc fk_alf_nass_snode; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_node_assoc
    ADD CONSTRAINT fk_alf_nass_snode FOREIGN KEY (source_node_id) REFERENCES public.alf_node(id);


--
-- Name: alf_node_assoc fk_alf_nass_tnode; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_node_assoc
    ADD CONSTRAINT fk_alf_nass_tnode FOREIGN KEY (target_node_id) REFERENCES public.alf_node(id);


--
-- Name: alf_node_assoc fk_alf_nass_tqn; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_node_assoc
    ADD CONSTRAINT fk_alf_nass_tqn FOREIGN KEY (type_qname_id) REFERENCES public.alf_qname(id);


--
-- Name: alf_node fk_alf_node_acl; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_node
    ADD CONSTRAINT fk_alf_node_acl FOREIGN KEY (acl_id) REFERENCES public.alf_access_control_list(id);


--
-- Name: alf_node fk_alf_node_loc; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_node
    ADD CONSTRAINT fk_alf_node_loc FOREIGN KEY (locale_id) REFERENCES public.alf_locale(id);


--
-- Name: alf_node fk_alf_node_store; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_node
    ADD CONSTRAINT fk_alf_node_store FOREIGN KEY (store_id) REFERENCES public.alf_store(id);


--
-- Name: alf_node fk_alf_node_tqn; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_node
    ADD CONSTRAINT fk_alf_node_tqn FOREIGN KEY (type_qname_id) REFERENCES public.alf_qname(id);


--
-- Name: alf_node fk_alf_node_txn; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_node
    ADD CONSTRAINT fk_alf_node_txn FOREIGN KEY (transaction_id) REFERENCES public.alf_transaction(id);


--
-- Name: alf_node_properties fk_alf_nprop_loc; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_node_properties
    ADD CONSTRAINT fk_alf_nprop_loc FOREIGN KEY (locale_id) REFERENCES public.alf_locale(id);


--
-- Name: alf_node_properties fk_alf_nprop_n; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_node_properties
    ADD CONSTRAINT fk_alf_nprop_n FOREIGN KEY (node_id) REFERENCES public.alf_node(id);


--
-- Name: alf_node_properties fk_alf_nprop_qn; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_node_properties
    ADD CONSTRAINT fk_alf_nprop_qn FOREIGN KEY (qname_id) REFERENCES public.alf_qname(id);


--
-- Name: alf_permission fk_alf_perm_tqn; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_permission
    ADD CONSTRAINT fk_alf_perm_tqn FOREIGN KEY (type_qname_id) REFERENCES public.alf_qname(id);


--
-- Name: alf_prop_link fk_alf_propln_key; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_prop_link
    ADD CONSTRAINT fk_alf_propln_key FOREIGN KEY (key_prop_id) REFERENCES public.alf_prop_value(id) ON DELETE CASCADE;


--
-- Name: alf_prop_link fk_alf_propln_root; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_prop_link
    ADD CONSTRAINT fk_alf_propln_root FOREIGN KEY (root_prop_id) REFERENCES public.alf_prop_root(id) ON DELETE CASCADE;


--
-- Name: alf_prop_link fk_alf_propln_val; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_prop_link
    ADD CONSTRAINT fk_alf_propln_val FOREIGN KEY (value_prop_id) REFERENCES public.alf_prop_value(id) ON DELETE CASCADE;


--
-- Name: alf_prop_unique_ctx fk_alf_propuctx_p1; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_prop_unique_ctx
    ADD CONSTRAINT fk_alf_propuctx_p1 FOREIGN KEY (prop1_id) REFERENCES public.alf_prop_root(id);


--
-- Name: alf_prop_unique_ctx fk_alf_propuctx_v1; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_prop_unique_ctx
    ADD CONSTRAINT fk_alf_propuctx_v1 FOREIGN KEY (value1_prop_id) REFERENCES public.alf_prop_value(id) ON DELETE CASCADE;


--
-- Name: alf_prop_unique_ctx fk_alf_propuctx_v2; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_prop_unique_ctx
    ADD CONSTRAINT fk_alf_propuctx_v2 FOREIGN KEY (value2_prop_id) REFERENCES public.alf_prop_value(id) ON DELETE CASCADE;


--
-- Name: alf_prop_unique_ctx fk_alf_propuctx_v3; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_prop_unique_ctx
    ADD CONSTRAINT fk_alf_propuctx_v3 FOREIGN KEY (value3_prop_id) REFERENCES public.alf_prop_value(id) ON DELETE CASCADE;


--
-- Name: alf_qname fk_alf_qname_ns; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_qname
    ADD CONSTRAINT fk_alf_qname_ns FOREIGN KEY (ns_id) REFERENCES public.alf_namespace(id);


--
-- Name: alf_store fk_alf_store_root; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_store
    ADD CONSTRAINT fk_alf_store_root FOREIGN KEY (root_node_id) REFERENCES public.alf_node(id);


--
-- Name: alf_subscriptions fk_alf_sub_node; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_subscriptions
    ADD CONSTRAINT fk_alf_sub_node FOREIGN KEY (node_id) REFERENCES public.alf_node(id) ON DELETE CASCADE;


--
-- Name: alf_subscriptions fk_alf_sub_user; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_subscriptions
    ADD CONSTRAINT fk_alf_sub_user FOREIGN KEY (user_node_id) REFERENCES public.alf_node(id) ON DELETE CASCADE;


--
-- Name: alf_usage_delta fk_alf_usaged_n; Type: FK CONSTRAINT; Schema: public; Owner: alfresco
--

ALTER TABLE ONLY public.alf_usage_delta
    ADD CONSTRAINT fk_alf_usaged_n FOREIGN KEY (node_id) REFERENCES public.alf_node(id);


--
-- PostgreSQL database dump complete
--

