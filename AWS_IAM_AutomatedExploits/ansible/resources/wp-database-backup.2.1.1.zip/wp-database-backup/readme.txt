=== WP Database Backup ===
Contributors: Prashant Walke
Donate link:http://walkeprashant.wordpress.com/wp-database-backup/	
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: Database backup,db backup ,backup, WordPress Database Backup, WP db backup,wp database backup,wp backup,wordpress backup, mysql backup,automatically database backup,website backup,website database backup,restore database backup,Store database backup on dropbox,ftp,email notification.
Requires at least: 3.1+
Tested up to: 3.9.1
Stable tag: trunk

WP Database Backup plugin helps you to create Database Backup and Restore Database Backup easily on single click.Manual or automated backups And also store database backup on safe place- dropbox,FTP,Email

== Description ==

WP Database Backup plugin helps you to create Database Backup and Restore Database Backup easily on single click.Manual or Automated Database Backups And also store database backup on safe place- dropbox,FTP,Email

<b> Features included <b>

Create Database Backup
WP Database Backup plugin helps you to create Database Backup easily on single click.

Autobackup
Backup automatically on a repeating schedule

Download backup file direct from your WordPress dashboard

Easy To Install
WP Database Backup is super easy to install. 

Restore Database Backup
WP Database Backup plugin helps you to Restore Database Backup easily on single click.

Store database backup on safe plac
Store database backup on safe place- dropbox,FTP,Email

Few of the Key Features :
1. Database Backup easily on single click
2. Autobackup
3. Restore Database Backup easily on single click
4. Store database backup on safe place- dropbox,FTP,Email

== Installation ==
1. Download the plugin file, unzip and place it in your wp-content/plugins/ folder. You can alternatively upload it via the WordPress plugin backend.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. WP Database Backup menu will appear in Dashboard->Tool->WP-DB-Backup. Click on it & get started to use.
4. Refer to the for <a href="http://walkeprashant.wordpress.com/wp-database-backup/">More Information</a>.

== Screenshots ==
1. wp_create_new_database_backup.jpeg
2. wp_database_backup.jpeg
3. wp_database_backup_auto_schedule.jpeg
4. wp_database_backup_download.jpeg

== Changelog ==

= 1.0.0 = 
*Plugin Created

= 2.0 = 
*Restore Database Backup on singe click
*Change look and feel

= 2.1 = 
*Store Database Backup FTP,Dropbox,Email
*Email Notification
*fixed bug: Warning: Illegal offset type in /wp-admin/includes/template.php
*Fixed bug: Warning: Illegal string offset 'enable_autobackups

= 2.1.1 = 
*Fixed bug: Conflict issue with Disqus Comments System, NextGen Gallery etc.

== Frequently Asked Questions ==

 Q-How to  create database Backup?
 Follow the steps listed below to Create Database Backup

 Create Backup:
  1) Click on Create New Database Backup
  2) Download Database Backup file.
  
 Q-How to restore database backup?
  Restore Backup:
  Click on Restore Database Backup 
  
  OR

  1)Login to phpMyAdmin
  2)Click Databases and select the database that you will be importing your data into.
  3)Across the top of the screen will be a row of tabs. Click the Import tab.
  4)On the next screen will be a location of text file box, and next to that a button named Browse.
  5)Click Browse. Locate the backup file stored on your computer.
  6)Click the Go button

 Q-Always get an empty (0 bits) backup file?
 Ans-This is generally caused by an access denied problem.
 You don't have permission to write in the wp-content/uploads. 
 Please check if you have the read write permission on the folder.
 
 Q.want more featur?
 If you want more feature then
 Drop Mail :walke.prashant28@gmail.com
  
== Upgrade Notice ==

= 1.0.0 =
Base version of the plugin. 
= 2.0 =
New Feature -Restore Database on Single click
= 2.1 =
New Feature-Store Database Backup FTP,Dropbox,Email
fixed bug- Illegal string offset
= 2.1.1 = 
*Fixed bug: Conflict issue with Disqus Comments System, NextGen Gallery etc.

== Official Site ==
For <a href="walkeprashant.wordpress.com/wp-database-backup/">More Information</a> Or Advanced feature drop mail:walke.prashant28@gmail.com